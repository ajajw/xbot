import requests
import json
import re

from pyrogram import Client
from pyrogram.types import Message
from carding.functions import *
from carding.database.checkuser_sql import already_added

@Client.on_message(cmd('bin'))
async def bchk_func(client, message: Message):
    user_id = message.from_user["id"]
    name = message.from_user["first_name"]

    try:
        query = ''
        for i in message.command[1:]:
            query += ' ' + str(i)
        if not query:
            await message.reply("**Input valid BIN\nEx: `/bin 435087`**"
                                )
            return
        if already_added(user_id):
            pass
        elif not already_added(user_id):
            await message.reply("Please **register** 1st..\nSend /register to registered")
            return
        xx = await message.reply("**Checking BIN...⌛**")
        ssd = re.sub("[^0-9|]+", '', query)
        splitter = ssd.split('|')
        cc = splitter[0]
        bin = cc[:6]

        res = requests.get("https://dragon-bin-api.vercel.app/api/" + bin)
        bin_data = json.loads(res.text)
        vendor = bin_data["data"]["vendor"]
        bank = bin_data["data"]["bank"]
        type = bin_data["data"]["type"]
        country = bin_data["data"]["country"]
        level = bin_data["data"]["level"]
        flag = bin_data["data"]["countryInfo"]["emoji"]

        valid = f"""
<b><u>BIN INFORMATION</u></b>

<b>Bin -</b> <code>{bin}</code>
<b>Status -</b> <code>Valid Bin ✅</code>
<b>Brand -</b> <code>{vendor}</code>
<b>Type -</b> <code>{type}</code>
<b>Level -</b> <code>{level}</code>
<b>Bank -</b> <code>{bank}</code>
<b>Country -</b> <code>{country} {flag}</code>

<b>•𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐁𝐲:</b> <a href="tg://user?id={user_id}">{name}</a> [ {ustat(user_id)} ]
<b>•𝐁𝐨𝐭 𝐁𝐲:</b> @xcardinglive
"""
        await xx.edit(valid, parse_mode="HTML")
    except Exception as e:
        await xx.edit("BIN not found!")
        print(e)
