import requests
import time
import re
from datetime import datetime

from pyrogram import Client
from pyrogram.types import Message
from carding.functions import *
from carding.database.checkuser_sql import already_added


@Client.on_message(cmd('vbv'))
async def vbx_func(client, message: Message):
    user_id = message.from_user["id"]
    name = message.from_user["first_name"]
    if is_spam(user_id):
        return await message.reply_text(text="**ANTISPAM!**\n`Wait in 5s and try again..`",reply_to_message_id=message.message_id)

    try:
        if already_added(user_id):
            pass
        elif not already_added(user_id):
            await message.reply_text(text="Please **register** 1st..\nSend /register to registered",reply_to_message_id=message.message_id)
            return
        query = ''
        for i in message.command[1:]:
            query += ' ' + str(i)
        if not query:
            await message.reply_text(text="**Input valid cc\nEx: `/vbv cc|mm|yy|cvv`**",reply_to_message_id=message.message_id)
            return

        start_time = time.time()
        xx = await message.reply_text(text="**Checking Your Card...⏳**",reply_to_message_id=message.message_id)

        splitter = re.findall(r"[0-9]+", query)
        cc = splitter[0]
        mes = splitter[1]
        ano = splitter[2]
        cvc = splitter[3]
        strlenx = len(cc)
        cvvd = cvc[:3]
        cvvx = cvc[:4]
        bin = cc[:6]
        if (strlenx < 16):
            cvv = cvvx
        else:
            cvv = cvvd
        resx = requests.get("https://dragon-bin-api.vercel.app/api/" + bin)
        vendor = getStr(resx.text, '"vendor":"', '"')
        bank = getStr(resx.text, '"bank":"', '"')
        type = getStr(resx.text, '"type":"', '"')
        country = getStr(resx.text, '"country":"', '"')
        level = getStr(resx.text, '"level":"', '"')
        flag = getStr(resx.text, '"emoji":"', '"')
        # -----------[ If Not Respond ]----------------
        vendor = "Null" if not vendor else vendor
        bank = "Null" if not bank else bank
        type = "Null" if not type else type
        country = "Null" if not country else country
        level = "Null" if not level else level

        lista = cc + "|" + mes + "|" + ano + "|" + cvv

        res = requests.get(
            "https://b3check.xprojects.repl.co/vbv.php?lista=" + lista)

        status = getStr(res.text, '"status":"', '"')
        enrol = getStr(res.text, '"enrolled":"', '"')

        stop_time = time.time() - start_time
        date = datetime.today().strftime('%d-%m-%Y')

        if 'lookup_not_enrolled' in res.text:
            await xx.edit_text(f"""
<b>𝐆𝐀𝐓𝐄 𝟑𝐃 𝐂𝐇𝐄𝐂𝐊 [ 𝐁𝟑 ]</b>
•━━━━━━━━━━━━━━━━━━━•
<code>{lista}</code>
╾──────────────────╼
<b>•𝟯𝗗 𝗖𝗵𝗲𝗰𝗸: FALSE ✅</b>
<b>•𝗦𝘁𝗮𝘁𝘂𝘀:</b> {status} [{enrol}]
<b>•𝗕𝗮𝗻𝗸 𝗡𝗮𝗺𝗲:</b> {bank}
<b>•𝗖𝗮𝗿𝗱 𝗕𝗿𝗮𝗻𝗱:</b> {vendor}
<b>•𝗖𝗮𝗿𝗱 𝗧𝘆𝗽𝗲:</b> {type} • {level}
<b>•𝗖𝗼𝘂𝗻𝘁𝗿𝘆:</b> {country} {flag}
•━━━━━━━━━━━━━━━━━━━•
<b>•𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐁𝐲:</b> <a href="tg://user?id={user_id}">{name}</a> [ {ustat(user_id)} ]
<b>•𝐁𝐨𝐭 𝐁𝐲:</b> @xcardinglive
<b>•𝐓𝐢𝐦𝐞:</b> <code>{stop_time:.02f}s</code> [ {date} ]
""", parse_mode="HTML")
        elif '"message":"Credit card number is invalid."' in res.text:
            await xx.edit_text(f"""
<b>𝐆𝐀𝐓𝐄 𝟑𝐃 𝐂𝐇𝐄𝐂𝐊 [ 𝐁𝟑 ]</b>
•━━━━━━━━━━━━━━━━━━━•
<code>{lista}</code>
╾──────────────────╼
<b>•𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲:</b> FAILED ⚠️
<b>•𝗠𝗲𝘀𝘀𝗮𝗴𝗲:</b> Credit card number is invalid.
<b>•𝗕𝗮𝗻𝗸 𝗡𝗮𝗺𝗲:</b> {bank}
<b>•𝗖𝗮𝗿𝗱 𝗕𝗿𝗮𝗻𝗱:</b> {vendor}
<b>•𝗖𝗮𝗿𝗱 𝗧𝘆𝗽𝗲:</b> {type} • {level}
<b>•𝗖𝗼𝘂𝗻𝘁𝗿𝘆:</b> {country} {flag}
•━━━━━━━━━━━━━━━━━━━•
<b>•𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐁𝐲:</b> <a href="tg://user?id={user_id}">{name}</a> [ {ustat(user_id)} ]
<b>•𝐁𝐨𝐭 𝐁𝐲:</b> @xcardinglive
<b>•𝐓𝐢𝐦𝐞:</b> <code>{stop_time:.02f}s</code> [ {date} ]
""", parse_mode="HTML")
        else:
            await xx.edit_text(f"""
<b>𝐆𝐀𝐓𝐄 𝟑𝐃 𝐂𝐇𝐄𝐂𝐊 [ 𝐁𝟑 ]</b>
•━━━━━━━━━━━━━━━━━━━•
<code>{lista}</code>
╾──────────────────╼
<b>•𝟯𝗗 𝗖𝗵𝗲𝗰𝗸: TRUE 🔴</b>
<b>•𝗦𝘁𝗮𝘁𝘂𝘀:</b> {status} [{enrol}]
<b>•𝗕𝗮𝗻𝗸 𝗡𝗮𝗺𝗲:</b> {bank}
<b>•𝗖𝗮𝗿𝗱 𝗕𝗿𝗮𝗻𝗱:</b> {vendor}
<b>•𝗖𝗮𝗿𝗱 𝗧𝘆𝗽𝗲:</b> {type} • {level}
<b>•𝗖𝗼𝘂𝗻𝘁𝗿𝘆:</b> {country} {flag}
•━━━━━━━━━━━━━━━━━━━•
<b>•𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐁𝐲:</b> <a href="tg://user?id={user_id}">{name}</a> [ {ustat(user_id)} ]
<b>•𝐁𝐨𝐭 𝐁𝐲:</b> @xcardinglive
<b>•𝐓𝐢𝐦𝐞:</b> <code>{stop_time:.02f}s</code> [ {date} ]
""", parse_mode="HTML")

    except Exception:
        await xx.edit_text("Invalid Request Error!")
        # print(e)
