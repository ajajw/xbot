from pyrogram import Client, filters
from pyrogram.types import Message

from carding.database.checkuser_sql import add_usersid_in_db, already_added


@Client.on_message(filters.command('register'))
async def rgstr(client, message: Message):
    user_id = message.from_user["id"]
    name = message.from_user["first_name"]
    if already_added(user_id):
        await message.reply("You already registered!")
    elif not already_added(user_id):
        await client.send_message(-1001592567920, f"**NEW USER STARTED** 🔥\n\n**Name:** {name}\n**ID:** {user_id}\n\n**Link Profile:** [Klick-Here](tg://user?id={user_id})")
        await message.reply(f"**Registered** successfully.\n**ID:** `{user_id}`\n**PLAN:** `Free`")
        add_usersid_in_db(user_id)
