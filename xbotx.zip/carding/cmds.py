
from pyrogram import Client
from pyrogram.types import InlineKeyboardButton
from pyrogram.types import InlineKeyboardMarkup
from pyrogram.types import Message
from carding.functions import cmd

CMDTEXT = """
Hi [{}](tg://user?id={})

Click Button below to check my cmd.
"""


@Client.on_message(cmd(['cmds', 'help']))
async def cmdx(client, message: Message):
    user_id = message.from_user["id"]
    name = message.from_user["first_name"]
    message.from_user
    button = InlineKeyboardMarkup(
        [
            [InlineKeyboardButton(
                "FREE 🎁", callback_data="free"
            ),
             InlineKeyboardButton(
                "PAID 💰", callback_data="paid")
            ],
            [InlineKeyboardButton(
                "OTHER ⚙️", callback_data="other"
            ),
             InlineKeyboardButton(
                "CLOSE ⭕", callback_data="close")
            ]
        ])
       

    await message.reply_text(CMDTEXT.format(name, user_id),
                             reply_markup=button)
