import math
import time as tm
import re
import random
import string
import requests
from random import choice
from typing import Union, List
from pyrogram import filters

def cmd(commands: Union[str, List[str]]):
    return filters.command(commands, ["/", "!", ".", "?"])

def getStr(data, first, last):
    """Get middle text from  full text
    Args:
        data (str): data
        first (any): [First text]
        last (any): [last text]
    Returns:
        [str]: [return middle text of first and last text]
    """
    try:
        start = data.index(first) + len(first)
        end = data.index(last, start)
        return data[start:end]
    except ValueError:
        return ''

#====================================================
def saveCVV(lista):
    success = open("carding/temp/cvv.txt", "a")
    success.write(lista + "\n")
    success.close()

def saveCCN(lista):
    success = open("carding/temp/ccn.txt", "a")
    success.write(lista + "\n")
    success.close()


def saveCH(lista):
    success = open("carding/temp/charge.txt", "a")
    success.write(lista + "\n")
    success.close()


spams = {}
msgs = 2  # Messages in
max = 10  # Seconds
ban = 10  # Seconds

def is_spam(user_id):
    try:
        usr = spams[user_id]
        usr["messages"] += 1
    except:
        spams[user_id] = {
            "next_time": int(
                tm.time()) + max,
            "messages": 1,
            "banned": 0}
        usr = spams[user_id]
    if usr["banned"] >= int(tm.time()):
        return True
    else:
        if usr["next_time"] >= int(tm.time()):
            if usr["messages"] >= msgs:
                spams[user_id]["banned"] = tm.time() + ban
                # text = """You're banned for {} minutes""".format(ban / 60)
                # await bot.send_message(user_id, text)
                # User is banned! alert him...
                return True
        else:
            spams[user_id]["messages"] = 1
            spams[user_id]["next_time"] = int(tm.time()) + max
    return False

#====================================================

def lista(dets):
    arrays = re.findall(r'[0-9]+', dets)
    return arrays 

def banned_bin(bin):
    file = open('carding/temp/bin.txt', 'a+')
    file.write(str(bin) + "\n")
    file.close()
    return banned_bin

def addprem(userid):
    file = open('carding/temp/Premium.txt', 'a+')
    file.write(userid + "\n")
    file.close()
    return addprem

def ustat(user_id):
    file = open('carding/temp/Premium.txt', 'r').readlines()
    if str(user_id) + "\n" in file:
       ustat = "Paid"
    elif user_id == 5032070399:
       ustat = "DEV"
    else:
       ustat = "Free"
    
    return ustat

def get_email(): 
    generated_email = str(''.join(random.choices(string.ascii_uppercase + string.digits, k = 8))) + '@gmail.com'
    return generated_email.lower()

arr = ["cparrgwn-rotate:7ci3t466wogk","xjhvddif-rotate:v6dk0h2aqd7a","biklweft-rotate:u9lhww5h3qun"]
proxy = choice(arr)
proxies = {
'http':f'http://{proxy}@p.webshare.io:80/',
'https':f'http://{proxy}@p.webshare.io:80/'
}

curl = requests.Session()
# curl.proxies = proxies

