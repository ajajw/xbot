from pyrogram import Client, filters
from pyrogram.types import CallbackQuery
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup


@Client.on_callback_query(filters.regex("close"))
async def close(client: Client, query: CallbackQuery):
    await query.message.delete()


@Client.on_callback_query(filters.regex("free"))
async def free(client: Client, query: CallbackQuery):
    await query.message.edit_text("""
Ξ <b>LIST FREE COMMAND</b> Ξ
━━━━━━━━━━━━━━━━━

⨭ <b><u>STRIPE AUTH</u></b> [✅]
➥ Ex: <code>/ss [cc|mm|yy|cvv]</code>

⨭ <b><u>STRIPE CHARGE 0,5$</u></b> [✅]
➥ Ex: <code>/ch [cc|mm|yy|cvv]</code>

⨭ <b><u>STRIPE CHARGE 1$</u></b> [✅]
➥ Ex: <code>/cc [cc|mm|yy|cvv]</code>

⨭ <b><u>STRIPE CHARGE 253$</u></b> [✅]
➥ Ex: <code>/cd [cc|mm|yy|cvv]</code>

⨭ <b><u>STRIPE WOO CHARGE 1$</u></b> [✅]
➥ Ex: <code>/sw [cc|mm|yy|cvv]</code>

⨭ <b><u>3D CHECK B3</u></b> [✅]
➥ Ex: <code>/vbv [cc|mm|yy|cvv]</code>

╾───────────────╼
⚠️ If you get any type of bugs in this bot
Please send ss to @X_ReportBot
•Maintained BY: @xcardinglive
""", parse_mode="HTML", reply_markup=InlineKeyboardMarkup(
        [
            [InlineKeyboardButton(
                "PAID 💰", callback_data="paid"
            ),
             InlineKeyboardButton(
                "OTHER ⚙️", callback_data="other"
            )
            ],
             [InlineKeyboardButton(
                "❌ CLOSE ❌", callback_data="close")
            ]
        ]))

@Client.on_callback_query(filters.regex("paid"))
async def paid(client: Client, query: CallbackQuery):
    await query.message.edit_text("""
Ξ <b>LIST PAID COMMAND</b> Ξ
━━━━━━━━━━━━━━━━━

⨭ <b><u>BRAINTREE AUTH</u></b> [✅]
➥ Ex: <code>/ba [cc|mm|yy|cvv]</code>

⨭ <b><u>SHOPIFY + B3 CHARGE 6$</u></b> [✅]
➥ Ex: <code>/sf [cc|mm|yy|cvv]</code>

⨭ <b><u>AUTHNET CHARGE 10$</u></b> [✅]
➥ Ex: <code>/au [cc|mm|yy|cvv]</code>

╾───────────────╼
⚠️ If you get any type of bugs in this bot
Please send ss to @X_ReportBot
•Maintained BY: @xcardinglive
""", parse_mode="HTML", reply_markup=InlineKeyboardMarkup(
        [
            [InlineKeyboardButton(
                "FREE 🎁", callback_data="free"
            ),
             InlineKeyboardButton(
                "OTHER ⚙️", callback_data="other"
            )
            ],
             [InlineKeyboardButton(
                "❌ CLOSE ❌", callback_data="close")
            ]
        ]))


@Client.on_callback_query(filters.regex("other"))
async def other(client: Client, query: CallbackQuery):
    await query.message.edit_text("""
Ξ <b>LIST OTHER COMMAND</b> Ξ
━━━━━━━━━━━━━━━━━

⨭ <b><u>FAKE ADDRESS</u></b>
➥ Ex: <code>/fake us</code>

⨭ <b><u>CC GENERATOR</u></b>
➥ Ex: <code>/gen 572628xxxxx</code>

⨭ <b><u>BIN CHECKER</u></b>
➥ Ex: <code>/bin 572628</code>

⨭ <b><u>SK_KEY CHECKER</u></b>
➥ Ex: <code>/sk sk_live_xxxxxxx</code>

⨭ <b><u>IP ADDRESS LOOKUP</u></b>
➥ Ex: <code>/ip 173.195.27.138 </code>

⨭ <b><u>USER PROFILE INFO</u></b>
➥ Ex: <code>/info </code>

⨭ <b><u>GET TELEGRAM ID</u></b>
➥ Ex: <code>/id </code>

⨭ <b><u>PING STATS BOT</u></b>
➥ Ex: <code>/ping </code>

╾───────────────╼
⚠️ If you get any type of bugs in this bot
Please inform to my dev @X_ReportBot
Maintained BY: @xcardinglive
""", parse_mode="HTML", reply_markup=InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                "❌ Close", callback_data="close")
            ]
        ]))
