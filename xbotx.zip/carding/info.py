import os
from pyrogram import Client
from pyrogram.types import Message

from pyrogram.errors.exceptions.bad_request_400 import BotMethodInvalid

from carding.functions import cmd

@Client.on_message(cmd('info'))
async def inf(client: Client, message: Message):
    xx = await message.reply("`Collecting Whois Info..`")
    msg = message.reply_to_message or message

    from_user = msg.from_user.id
    from_chat = msg.chat.id

    if from_user or from_chat is not None:
        pp_c = await client.get_profile_photos_count(from_user)
        message_out_str = "<b>USER INFO:</b>\n\n"
        message_out_str += f"<b>🗣 First Name:</b> <code>{msg.from_user.first_name}</code>\n"
        message_out_str += f"<b>🗣 Last Name:</b> <code>{msg.from_user.last_name}</code>\n"
        message_out_str += f"<b>👤 Username:</b> @{msg.from_user.username}\n"
        message_out_str += f"<b>🏢 DC ID:</b> <code>{msg.from_user.dc_id}</code>\n"
        message_out_str += f"<b>🤖 Is Bot:</b> <code>{msg.from_user.is_bot}</code>\n"
        message_out_str += f"<b>🚫 Is Restricted:</b> <code>{msg.from_user.is_scam}</code>\n"
        message_out_str += "<b>✅ Is Verified by Telegram:</b> "
        message_out_str += f"<code>{msg.from_user.is_verified}</code>\n"
        message_out_str += f"<b>🕵️‍♂️ User ID:</b> <code>{msg.from_user.id}</code>\n"
        message_out_str += f"<b>🖼 Profile Photos:</b> <code>{pp_c}</code>\n"
        try:
            cc_no = len(await client.get_common_chats(from_user))
        except BotMethodInvalid:
            pass
        else:
            message_out_str += f"<b>👥 Common Chats:</b> <code>{cc_no}</code>\n"
        message_out_str += f"<b>👁 Last Seen:</b> <code>{msg.from_user.status}</code>\n"
        message_out_str += "<b>🔗 Permanent Link To Profile:</b> "
        message_out_str += f"<a href='tg://user?id={msg.from_user.id}'>Here</a>"

        s_perm = True
        if message.chat.permissions:
            s_perm = bool(message.chat.permissions.can_send_media_messages)
        if msg.from_user.photo and s_perm:
            local_user_photo = await client.download_media(
                message=msg.from_user.photo.big_file_id)
            await client.send_photo(chat_id=message.chat.id,
                                    photo=local_user_photo,
                                    caption=message_out_str,
                                    parse_mode="html",
                                    disable_notification=True)
            os.remove(local_user_photo)
            await xx.delete()
        else:
            cuz = "Chat Send Media Forbidden" if not s_perm else "NO DP Found"
            message_out_str = "<b>📷 " + cuz + " 📷</b>\n\n" + message_out_str
            await xx.edit(message_out_str)
