import requests
import time
import json
from requests.auth import HTTPBasicAuth

from pyrogram import Client
from pyrogram.types import Message
from carding.functions import cmd
from carding.database.checkuser_sql import already_added

@Client.on_message(cmd('sk'))
async def sk_func(client, message: Message):
    message.text
    user_id = message.from_user["id"]
    message.from_user["first_name"]

    try:
        sk_key = ''
        for i in message.command[1:]:
            sk_key += ' ' + str(i)
        if not sk_key:
            await message.reply("**Input valid key\nEx: `/sk sk_live_xxxxxxxxx`**"
                                )
            return
        if already_added(user_id):
            pass
        elif not already_added(user_id):
            await message.reply("Please **register** 1st..\nSend /register to registered")
            return

        time.time()
        xx = await message.reply("`Checking Sk_Key...`")

        headers = {
            "user-agent": "Mozilla/5.0 (Linux; Android 11; M2101K7AG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.56 Mobile Safari/537.36"}
        data = f"card[number]=4543218722787334&card[exp_month]=07&card[exp_year]=2026&card[cvc]=780"

        res = requests.post(
            "https://api.stripe.com/v1/tokens",
            auth=HTTPBasicAuth(
                f'{sk_key}',
                f'{sk_key}'),
            headers=headers,
            data=data)
        json.loads(res.text)

        if 'api_key_expired' in res.text:
            await xx.edit(f"""
━━━━[ SK CHECKER ]━━━━

<b>𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➾ DEAD SK KEY 🔴</b>
<b>𝗠𝗲𝘀𝘀𝗮𝗴𝗲 :</b> Expired key

➾ Key: <code>{sk_key}</code>

•━━━━━━━━━━━━━━━━•
<b>•𝐁𝐨𝐭 𝐁𝐲:</b> <a href="https://t.me/X_DEVX">IM NOOB</a>
""", parse_mode="HTML")
        elif '"code":"rate_limit"' in res.text:
            await xx.edit(f"""
━━━━[ SK CHECKER ]━━━━

<b>𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➾ LIMIT SK KEY ⚠️</b>
<b>𝗠𝗲𝘀𝘀𝗮𝗴𝗲 :</b> Sk Key Limited

➾ Key: <code>{sk_key}</code>

•━━━━━━━━━━━━━━━━•
<b>•𝐁𝐨𝐭 𝐁𝐲:</b> <a href="https://t.me/X_DEVX">IM NOOB</a>
""", parse_mode="HTML")
        elif 'testmode_charges_only' in res.text:
            await xx.edit(f"""
━━━━[ SK CHECKER ]━━━━

<b>𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➾ DEAD SK KEY 🔴</b>
<b>𝗠𝗲𝘀𝘀𝗮𝗴𝗲 :</b> testmode_charges_only

➾ Key: <code>{sk_key}</code>

•━━━━━━━━━━━━━━━━•
<b>•𝐁𝐨𝐭 𝐁𝐲:</b> <a href="https://t.me/X_DEVX">IM NOOB</a>
""", parse_mode="HTML")
        elif 'Invalid API Key provided' in res.text:
            await xx.edit(f"""
━━━━[ SK CHECKER ]━━━━

<b>𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➾ DEAD SK KEY 🔴</b>
<b>𝗠𝗲𝘀𝘀𝗮𝗴𝗲 :</b> Invalid Sk Key!

➾ Key: <code>{sk_key}</code>

•━━━━━━━━━━━━━━━━•
<b>•𝐁𝐨𝐭 𝐁𝐲:</b> <a href="https://t.me/X_DEVX">IM NOOB</a>
""", parse_mode="HTML")
        else:
            await xx.edit(f"""
━━━━[ SK CHECKER ]━━━━

<b>𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➾ LIVE KEY ✅</b>
<b>𝗠𝗲𝘀𝘀𝗮𝗴𝗲 :</b> Sk key live

➾ Key: <code>{sk_key}</code>

•━━━━━━━━━━━━━━━━•
<b>•𝐁𝐨𝐭 𝐁𝐲:</b> <a href="https://t.me/X_DEVX">IM NOOB</a>
""", parse_mode="HTML")

    except Exception:
        await xx.edit("Invalid Request Error!")
