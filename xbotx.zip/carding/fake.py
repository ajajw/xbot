import requests
import random
from pyrogram import Client
from pyrogram.types import Message

from carding.functions import *
from carding.database.checkuser_sql import already_added

@Client.on_message(cmd(['fake', 'rnd']))
async def fak_func(client, message: Message):
    user_id = message.from_user["id"]
    message.from_user["first_name"]
    try:
        if already_added(user_id):
            pass
        elif not already_added(user_id):
            await message.reply("Please **register** 1st..\nSend /register to registered")
            return
        query = ''
        for i in message.command[1:]:
            query += ' ' + str(i)
        if not query:
            await message.reply("**Input valid country code\nEx: `/fake us`**"
                                )
            return
        xx = await message.reply("`Generating address...`")

        url1 = f'https://www.bestrandoms.com/random-address-in-{query}?quantity=1'

        headers1 = {
            "authority": "www.bestrandoms.com",
            "path": f"/random-address-in-{query}?quantity=1",
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "referer": f"https://www.bestrandoms.com/random-address-in-{query}",
            "content-type": "application/x-www-form-urlencoded",
            "user-agent": "Mozilla/5.0 (Linux; Android 11; M2101K7AG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.49 Mobile Safari/537.36"}

        res = curl.get(
            url=url1,
            headers=headers1,
            data='quantity=1')
        # print(res.text)
        country = getStr(
            res.text,
            '<span><b>Country</b>&nbsp;&nbsp;',
            '</span>')
        street = getStr(
            res.text,
            '<span><b>Street:</b>&nbsp;&nbsp;',
            '</span>')
        city = getStr(res.text, '<span><b>City:</b>&nbsp;&nbsp;', '</span>')
        state = getStr(
            res.text,
            '<span><b>State/province/area: </b>&nbsp;&nbsp;',
            '</span>')
        zip = getStr(res.text, '<span><b>Zip code</b>&nbsp;&nbsp;', '</span>')
        phone = getStr(
            res.text,
            '<span><b>Phone number</b>&nbsp;&nbsp;',
            '</span>')

        country = "Unavailable" if not country else country
        street = "Unavailable" if not street else street
        city = "Unavailable" if not city else city
        state = "Unavailable" if not state else state
        zip = "Unavailable" if not zip else zip
        phone = "Unavailable" if not phone else phone

        await xx.edit(f"""
<b>FAKE ADDRESS GENERATOR</b>
╾─────────────────╼

<b>🗺️ 𝗖𝗼𝘂𝗻𝘁𝗿𝘆:</b> <code>{country.upper()}</code>
<b>🛣️ 𝗦𝘁𝗿𝗲𝗲𝘁:</b> <code>{street}</code>
<b>🌇 𝗖𝗶𝘁𝘆 :</b> <code>{city}</code>
<b>🏠 𝗦𝘁𝗮𝘁𝗲:</b> <code>{state}</code>
<b>📮 𝗭𝗶𝗽 𝗖𝗼𝗱𝗲:</b> <code>{zip}</code>
<b>☎️ 𝗣𝗵𝗼𝗻𝗲:</b> <code>{phone}</code>

<b>©</b> <code>bestrandoms.com</code>
╾─────────────────╼
""", parse_mode="HTML")

    except Exception as e:
        await xx.edit("Invalid Request Error!")
        print(e)
