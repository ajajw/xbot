from time import time
from pyrogram import Client, filters

from carding.functions import *
from carding.database.checkuser_sql import get_all_users
from carding.database.blacklist_sql import add_nibba_in_db, is_he_added, removenibba

from Config import OWN_ID


@Client.on_message(cmd('add'))
async def addp(client, message):
    user_id = message.from_user["id"]
    message.from_user["first_name"]
    try:
        if user_id == 5032070399 or user_id == 1762195232:
            pass
        else:
            await message.reply("**SORRY!**\nThis cmd only for devs users..")
            return
        userid = ''
        for i in message.command[1:]:
            userid += '' + str(i)
        if not userid:
            await message.reply("input ID!")
            return
        print(userid)
        filex = open('carding/temp/Premium.txt', 'r').readlines()
        if userid + "\n" not in filex:
            addprem(userid)
            await message.reply_text(text=f"<b>{userid} Successfully Added to PREMIUM</b>", reply_to_message_id=message.message_id)
        else:
            await message.reply_text(text="<b>ALREADY EXIST!</b>", reply_to_message_id=message.message_id)

    except Exception as e:
        await message.reply(f"Invalid Request Error!\n\nLogs: {e}")
        print(e)

@Client.on_message(cmd('unadd'))
async def unaddp(client, message):
    user_id = message.from_user["id"]
    message.from_user["first_name"]
    try:
        if user_id == 5032070399:
            pass
        else:
            await message.reply("**SORRY!**\nThis cmd only for devs users..")
            return
        userid = ''
        for i in message.command[1:]:
            userid += '' + str(i)
        if not userid:
            await message.reply("input ID!")
            return
        string_to_delete = userid
        input = open('carding/temp/Premium.txt', 'r').readlines()
        output = open('carding/temp/Premium.txt', 'w')
        if userid + "\n" not in input:
            await message.reply_text(text=f"<b>{userid} Nothing in Premium list!</b>", reply_to_message_id=message.message_id)
        else:
            for line in input:
               for word in string_to_delete:
                  line = line.replace(word, "")
               output.write(line)
            await message.reply_text(text=f"<b>{userid} Successfully deleted in Premium list!</b>", reply_to_message_id=message.message_id)

    except Exception as e:
        await message.reply(f"Invalid Request Error!")
        print(e)

@Client.on_message(cmd('addbin') & filters.user(OWN_ID))
async def bbin(client, message):
    try:  
         input = lista(message.text)
         cc = input[0]
         bin = cc[:6]
        
         filex = open('carding/temp/bin.txt', 'r').readlines()
         if str(bin) + "\n" not in filex:
            banned_bin(bin)
            await message.reply_text(text=f"<b>{bin} Successfully Added to Blacklist</b>",reply_to_message_id=message.message_id)
         else:
            await message.reply_text(text="<b>ALREADY BANNED</b>",reply_to_message_id=message.message_id)
    
    except Exception as e:
        await message.reply(f"Invalid Request Error!\n\nLogs: {e}")
        print(e)

@Client.on_message(cmd('stats') & filters.user(OWN_ID))
async def get_stats(client, message):
    starkisnoob = get_all_users()
    await message.reply(f"<b>I have <u>{len(starkisnoob)}</u> Users In Database.</b>", parse_mode="HTML")


@Client.on_message(cmd('block') & filters.user(OWN_ID))
async def blck(client, message):
    try:
        query = ''
        for i in message.command[1:]:
            query += ' ' + str(i)
        if not query:
            await message.reply("**Input valid id\nEx: `/block 1234333`**"
                                )
            return
        userid = str(query)
        if is_he_added(userid):
            await message.reply(f"User_ID: {userid}\nAlready Blacklisted.")
        elif not is_he_added(userid):
            add_nibba_in_db(userid)
            await message.reply(f"User_ID: {userid}\nHas been Blacklisted in this bot")

    except Exception as e:
        await message.reply(f"Invalid Request Error!\n\nLogs: {e}")
        print(e)


@Client.on_message(cmd('unblock') & filters.user(OWN_ID))
async def unblc(client, message):
    try:
        query = ''
        for i in message.command[1:]:
            query += ' ' + str(i)
        if not query:
            await message.reply("**Input valid id\nEx: `/unblock 1223453`**"
                                )
            return
        userid = str(query)
        if not is_he_added(userid):
            await message.reply(f"User_ID: {userid}\nNot Blacklisted.")
        elif is_he_added(userid):
            removenibba(userid)
            await message.reply(f"User_ID: {userid}\nHas been deleted from Blacklist.")

    except Exception as e:
        await message.reply(f"Invalid Request Error!\n\nLogs: {e}")
        print(e)


@Client.on_message(cmd('getcvv') & filters.user(OWN_ID))
async def getcv(client, message):
    start_time = time()
    xfile = open("carding/temp/cvv.txt", "r")
    count = len(xfile.readlines())
    await client.send_document(message.chat.id, "carding/temp/cvv.txt", caption=f"`Count` {count}")
    xfile.close()


@Client.on_message(cmd('getccn') & filters.user(OWN_ID))
async def getcn(client, message):
    start_time = time()
    xfile = open("carding/temp/ccn.txt", "r")
    count = len(xfile.readlines())
    await client.send_document(message.chat.id, "carding/temp/ccn.txt", caption=f"`Count` {count}")
    xfile.close()


@Client.on_message(cmd('getchg') & filters.user(OWN_ID))
async def getch(client, message):
    start_time = time()
    xfile = open("carding/temp/charge.txt", "r")
    count = len(xfile.readlines())
    await client.send_document(message.chat.id, "carding/temp/charge.txt", caption=f"`Count` {count}")
    xfile.close()
