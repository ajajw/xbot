import time
import psutil

from psutil._common import bytes2human
from pyrogram import Client, filters
from datetime import datetime
from carding.functions import cmd

from sys import version_info

from pyrogram import __version__ as __pyro_version__  # noqa

__python_version__ = f"{version_info[0]}.{version_info[1]}.{version_info[2]}"

StartTime = time.time()


async def generate_sysinfo(workdir):
    # uptime
    info = {
        'boot': (datetime.fromtimestamp(psutil.boot_time())
                 .strftime("%Y-%m-%d %H:%M:%S"))
    }
    # CPU
    cpu_freq = psutil.cpu_freq().current
    if cpu_freq >= 1000:
        cpu_freq = f"{round(cpu_freq / 1000, 2)}GHz"
    else:
        cpu_freq = f"{round(cpu_freq, 2)}MHz"
    info['cpu'] = (
        f"{psutil.cpu_percent(interval=1)}% "
        f"({psutil.cpu_count()}) "
        f"{cpu_freq}"
    )
    # Memory
    vm = psutil.virtual_memory()
    sm = psutil.swap_memory()
    info['ram'] = (f"{bytes2human(vm.total)}, "
                   f"{bytes2human(vm.available)} available")
    info['swap'] = f"{bytes2human(sm.total)}, {sm.percent}%"
    # Disks
    du = psutil.disk_usage(workdir)
    dio = psutil.disk_io_counters()
    info['disk'] = (f"{bytes2human(du.used)} / {bytes2human(du.total)} "
                    f"({du.percent}%)")
    if dio:
        info['disk io'] = (f"R {bytes2human(dio.read_bytes)} | "
                           f"W {bytes2human(dio.write_bytes)}")
    # Network
    nio = psutil.net_io_counters()
    info['net io'] = (f"TX {bytes2human(nio.bytes_sent)} | "
                      f"RX {bytes2human(nio.bytes_recv)}")
    # Sensors
    sensors_temperatures = psutil.sensors_temperatures()
    if sensors_temperatures:
        temperatures_list = [
            x.current
            for x in sensors_temperatures['coretemp']
        ]
        temperatures = sum(temperatures_list) / len(temperatures_list)
        info['temp'] = f"{temperatures}\u00b0C"
    info = {f"{key}:": value for (key, value) in info.items()}
    max_len = max(len(x) for x in info)
    return ("```"
            + "\n".join([f"{x:<{max_len}} {y}" for x, y in info.items()])
            + "```")


async def get_readable_time(seconds: int) -> str:
    count = 0
    up_time = ""
    time_list = []
    time_suffix_list = ["s", "m", "h", "days"]

    while count < 4:
        count += 1
        remainder, result = divmod(
            seconds, 60) if count < 3 else divmod(
            seconds, 24)
        if seconds == 0 and remainder == 0:
            break
        time_list.append(int(result))
        seconds = int(remainder)

    for x in range(len(time_list)):
        time_list[x] = str(time_list[x]) + time_suffix_list[x]
    if len(time_list) == 4:
        up_time += time_list.pop() + ", "

    time_list.reverse()
    up_time += ":".join(time_list)

    return up_time


@Client.on_message(filters.user(5032070399) & filters.command("sysinfo"))
async def get_sysinfo(client, m):
    response = "**System Information**:\n"
    m_reply = await m.reply_text(f"{response}`...`")
    response += await generate_sysinfo(client.workdir)
    await m_reply.edit_text(response)


@Client.on_message(cmd('botver'))
async def btvr(_, message):
    xx = await message.reply("`Checking Bot Version...`")
    uptime = await get_readable_time((time.time() - StartTime))
    output = f"""
        **BOT INFORMATION**

**NAME        :** 𝐗𝐂𝐀𝐑𝐃𝐈𝐍𝐆 𝐁𝐎𝐓
**USERNAME :** @X_CardingBot
━━━━━━━━━━━━━━━━━━━━━
💻 **Base on   : Python × Pyrogram**
🐍 **Python     :** {__python_version__}
⚙️ **Pyrogram :** {__pyro_version__}
🕒 **Uptime    :** {uptime}

Maintain: @xcardinglive
"""

    await xx.edit(output)


@Client.on_message(filters.command('ping'))
async def ping(_, message):
    uptime = await get_readable_time((time.time() - StartTime))
    start = datetime.now()
    msg = await message.reply('`Pong!`')
    end = datetime.now()
    latency = (end - start).microseconds / 1000
    await msg.edit(f"**PONG!** 🔥\n**Pinger:** `{latency}ms`\n**Uptime:** {uptime}")
