# Copyright (C) 2023  @Zygen_XD

from pyrogram import Client
from pyrogram.types import InlineKeyboardButton
from pyrogram.types import InlineKeyboardMarkup
from pyrogram.types import Message
from pyrogram import filters

STRTEXT = """
Hai [{}](tg://user?id={})
Im XCARDINGBOT
For Checking Your CC

Send /cmds to check my commands.
"""


@Client.on_message(filters.command("start"))
async def start_(client: Client, message: Message):
    user_id = message.from_user["id"]
    name = message.from_user["first_name"]
    user = message.from_user
    button = InlineKeyboardMarkup(
        [
            [InlineKeyboardButton(
                "☠️ OFFICIAL CHANNELS ☠️", url="https://t.me/xcardinglive")
             ]])
    if user.photo:
        photos = await client.get_profile_photos(user.id, limit=1)
        await message.reply_photo(photo=photos[0].file_id,
                                  caption=STRTEXT.format(name, user_id),
                                  reply_markup=button)
    else:
        await message.reply_text(STRTEXT.format(name, user_id),
                                 reply_markup=button)
