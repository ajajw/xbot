import requests
import json

from pyrogram import Client
from pyrogram.types import Message

from carding.functions import *
from carding.database.checkuser_sql import already_added

@Client.on_message(cmd('ip'))
async def prx_func(client, message: Message):
    message.text
    user_id = message.from_user["id"]
    message.from_user["first_name"]

    try:
        query = ''
        for i in message.command[1:]:
            query += ' ' + str(i)
        if not query:
            await message.reply("**Input valid cc\nEx: `/ip 173.195.27.138`**"
                                )
            return
        if already_added(user_id):
            pass
        elif not already_added(user_id):
            await message.reply("Please **register** 1st..\nSend /register to registered")
            return
        xx = await message.reply("`Checking IP address...`")

        res = requests.get(f"http://ipinfo.io/{query}/json")
        respon = json.loads(res.text)
        ipx = respon["ip"]
        citi = respon["city"]
        regi = respon["region"]
        countr = respon["country"]
        orgn = respon["org"]
        timez = respon["timezone"]
        postal = getStr(res.text, '"postal": "', '"')
        postal = "null" if not postal else postal
        await xx.edit(f"""
<b><u>-=[ IP ADDRESS INFORMATION ]=-</u></b>

<b>IP Address  =</b> <code>{ipx}</code>
<b>Country  =</b> {countr}
<b>City     =</b> {citi}
<b>Region   =</b> {regi}
<b>Zip Code =</b> {postal}
<b>Timezone =</b> <code>{timez}</code>
<b>Community=</b> <i>{orgn}</i>

""", parse_mode="HTML")

    except Exception:
        await xx.edit("IP not found!")
