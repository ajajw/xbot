import os

ENVIRONMENT = os.environ.get('ENVIRONMENT', False)

if ENVIRONMENT:
    try:
        API_ID = int(os.environ.get('API_ID', 0))
    except ValueError:
        raise Exception("Your API_ID is not a valid integer.")
    API_HASH = os.environ.get('API_HASH', None)
    BOT_TOKEN = os.environ.get('BOT_TOKEN', None)
    DATABASE_URL = os.environ.get('DATABASE_URL', None)
    OWN_ID = int(os.environ.get('OWN_ID', 0))
    
else:
    # Fill the Values
    API_ID = 
    API_HASH = ""
    BOT_TOKEN = ""
    DATABASE_URL = "postgresql://postgres:EvF8WoZIi2MARmF9TAPR@containers-us-west-44.railway.app:6483/railway"
    OWN_ID = 1639301986
    
